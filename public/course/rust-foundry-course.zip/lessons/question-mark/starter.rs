fn number(text: &str) -> Result<u32, &'static str> {
    match text.parse::<u32>() { Ok(value) => Ok(value), Err(_) => Err("bad number") }
}

fn add_text(a: &str, b: &str) -> Result<u32, &'static str> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(add_text("x", "2"), Err("bad number"));
    assert_eq!(add_text("4294967295", "1"), Err("overflow"));
    assert_eq!(add_text("19", "23"), Ok(42));
    println!("{}", add_text("19", "23").unwrap());
}
