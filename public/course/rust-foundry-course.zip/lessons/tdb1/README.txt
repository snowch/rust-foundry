Exchange files with C Foundry

TDB1 is the exchange format shared with C Foundry. Its eight-byte header is TDB1, version 1, row size 40, one byte of row count, and a zero reserved byte. It supports at most 128 rows.

Each row is a little-endian u32 id, 32 bytes for a zero-terminated UTF-8 name, and a little-endian u32 score. TinyDB’s normal RDB2 format stores indexed pages instead; .export creates a separate TDB1 file and .import accepts either format.

Expected output:
1 row header

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Validate the eight-byte header before reading count.
Hint 2: Check bytes.len() == 8 + count * 40 and count <= 128.

Experiment: Download exchange.tdb from the workspace and import it into C Foundry’s TinyDB.
