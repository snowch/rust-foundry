fn main() {
    let score = 50;
    if score > 50 {
        println!("pass");
    } else {
        println!("retry");
    }
}
