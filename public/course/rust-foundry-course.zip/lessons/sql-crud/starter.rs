fn updated_score(old: u32, replacement: u32) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(updated_score(90, 95), 95);
    println!("{}", updated_score(90, 95));
}
