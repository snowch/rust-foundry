fn stage(original: &[u32], value: u32) -> Vec<u32> {
    let mut candidate = original.to_vec();
    candidate.push(value);
    candidate
}

fn main() {
    let committed = vec![1, 2];
    let candidate = stage(&committed, 3);
    assert_eq!(committed, [1, 2]);
    assert_eq!(candidate, [1, 2, 3]);
    println!("committed {committed:?}; staged {candidate:?}");
}
