Represent alternatives

An enum represents a choice between named variants, each with its own payload. match makes each state visible at the point where you handle it.

TinyDB’s page type is an enum: a leaf has rows and a next link, while a branch has separator keys and child page IDs. A single struct full of unrelated optional fields would allow more invalid combinations.

Expected output:
lookup 42

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Match both Command variants explicitly.
Hint 2: Bind the Lookup payload to id in its match pattern.

Experiment: Add a Delete(u32) variant and update the exhaustive match.
