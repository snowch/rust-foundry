Follow a moved String

Goal: Trace ownership through a String parameter and returned value.
Before this lesson: Build formatted text as a value

The previous lessons created and changed owned text. Now follow who owns that String: a String parameter takes ownership when it receives the caller’s value.

In decorate(name), ownership moves from name in main into the function’s parameter. Returning the parameter moves ownership into decorated in the caller. A move does not clone the text.

The parameter uses mut because it appends text with the method you already know. After the call, decorated is usable and the original name binding is no longer usable.

The assertions and output use the new owner. To read the text without transferring ownership, we will introduce references in the next chapter.

Expected output:
Ada!

Exercise: In the practice editor’s main.rs, replace the todo! line in decorate. Keep main and its supplied checks. Choose Run checks.

Hint 1: The parameter is mutable, so push_str can append in place.
Hint 2: Return name after appending an exclamation mark.

Browser experiment: In the worked program’s main.rs, replace println!("{decorated}"); with println!("{name}");. Run again and compare. Read the moved-value message. Which call transferred ownership away from name?
