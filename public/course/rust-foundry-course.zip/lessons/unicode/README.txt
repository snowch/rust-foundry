Distinguish bytes from letters

Goal: Explain why UTF-8 text can occupy more bytes than visible letters.
Before this lesson: Read a view of text with &str; Say what kind of number you mean

A byte is a small storage unit represented by u8, a number from zero through 255. UTF-8 is the rule Rust uses to represent text as bytes. English letters such as A occupy one byte, but é occupies two.

text.len() counts bytes, not visible letters. café has five bytes: c, a, and f use one each, and é uses two. This distinction matters when a file reserves a fixed number of bytes for a name.

Double quotes describe text such as "Ada". Single quotes describe one Rust character, such as 'A'. A character has type char. To put a quote inside a character literal, escape it as '\''; \n inside text represents a newline and \0 represents a zero byte.

Text provides .bytes() to visit its UTF-8 bytes and .chars() to visit its characters. A for loop can visit them as it visits a numeric range. A later lesson will explain the iterator interface behind these operations.

Expected output:
5 bytes
c
a
f
é

Exercise: Change cafe to café. Observe the byte length and the four character lines.

Hint 1: Use the accented final letter é in the text.
Hint 2: The text needs to be "café", not "cafe".

Experiment: Replace the text with a single crab emoji and compare its byte length with its character output.
