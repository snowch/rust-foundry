Implement binary search

Goal: Shrink a sorted half-open interval until a target is found or the interval is empty.
Before this lesson: Big O: time, space, and input cases; Represent a missing value; Borrow part of an array

The earlier sorted-vector lesson used the library’s binary_search. Here implement the search itself. A sorted slice lets each comparison rule out half of the remaining candidates.

Track a half-open interval [lo, hi): lo is included and hi is excluded. Initially it spans 0..values.len(). While lo < hi, mid = lo + (hi − lo) / 2 is a valid index.

An equal value returns Some(mid). A smaller middle value moves lo to mid + 1; a larger middle value moves hi to mid. Both updates strictly shrink the interval, including when the slice is empty or has one element.

Each step halves the candidate count, giving O(log n) worst-case time and O(1) auxiliary space. The input must be sorted. With duplicates, this implementation can return any matching position, not necessarily the first.

Expected output:
5

Exercise: In the practice editor’s main.rs, replace the todo! line in search. Keep main and its supplied checks. Choose Run checks.

Hint 1: Use lo = 0 and hi = values.len(); continue while lo < hi.
Hint 2: Return on equality, move lo to mid + 1 for a smaller middle value, otherwise set hi = mid.

Browser experiment: In the worked program’s main.rs, replace println!("{}", search(&values, 23).unwrap()); with println!("{:?}", search(&values, 57));. Run again and compare. Compare the index for the present value with the result for 57. How does the return value represent a missing match?
