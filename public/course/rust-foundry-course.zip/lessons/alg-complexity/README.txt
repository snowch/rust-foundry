Big O: time, space, and input cases

Goal: Count distinct pair visits and distinguish linear from quadratic growth.
Before this lesson: Give a recurring type a readable name; Repeat work with a loop

Complexity models how work grows as the number of input items n increases. It describes operations and storage, not milliseconds on a specific computer. A scan visits n items, so its time is O(n).

Comparing every distinct pair performs n(n−1)/2 comparisons. The quadratic term dominates as n grows, so this work is O(n²). The helper below counts actual loop visits rather than assuming its output proves an algorithm is fast.

Auxiliary space measures extra storage beyond the input. Two counters need O(1) extra space even if their loops perform O(n²) work. Best, average, and worst cases refer to different inputs; a worst-case bound is not an average timing prediction.

The outer range chooses the first item. The inner range starts at i + 1, so each unordered pair is counted once and no item is paired with itself. Small test inputs keep the u64 arithmetic safely in range.

Expected output:
28

Exercise: In the practice editor’s main.rs, replace the todo! line in pair_visits. Keep main and its supplied checks. Choose Run checks.

Hint 1: Initialize visits to zero before both loops.
Hint 2: For i in 0..n, iterate _j in i + 1..n and increment visits.

Browser experiment: In the worked program’s main.rs, replace println!("{}", pair_visits(8)); with println!("{}", pair_visits(16));. Run again and compare. Compare visits for 8 and 16. Is the change proportional to the number of items? These are counted visits.
