Change through one mutable borrow

&mut gives exclusive access for the duration of a borrow. This lets a helper update a value while the caller keeps ownership.

The rule prevents simultaneous access that could invalidate assumptions. After the final use of a mutable borrow, the owner can usually be used again.

Expected output:
20

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Dereference the parameter to reach its u32.
Hint 2: Add five to the referenced integer.

Experiment: Hold two mutable references and try to use both; read E0499.
