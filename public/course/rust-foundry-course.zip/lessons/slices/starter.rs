fn first_or_zero(values: &[u32]) -> u32 {
    todo!("Implement slices")
}

fn main() {
    assert_eq!(first_or_zero(&[]), 0);
    let values = vec![9, 8, 7];
    assert_eq!(first_or_zero(&values[1..]), 8);
    println!("{}", first_or_zero(&values));
}
