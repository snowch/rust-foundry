Graphs and breadth-first search

Goal: Find the shortest edge count in an unweighted graph while avoiding repeated visits.
Before this lesson: Queues: first in, first out; Binary search trees and height; Record whether a value was seen

A graph represents vertices and edges. An adjacency list stores each vertex’s neighboring vertex numbers in a Vec. An undirected edge appears in both endpoint lists.

Breadth-first search uses VecDeque as a queue. Start at distance zero; every newly discovered neighbor gets the current distance plus one. The distance Vec starts at −1 to mark unseen vertices.

Record a neighbor’s distance before push_back so a cycle cannot enqueue it repeatedly. pop_front processes the oldest discovered vertex, finishing distance d before distance d + 1. That is why the first discovered distance is shortest for equal-cost edges.

BFS takes O(V + E) time and O(V) auxiliary space beyond the graph: V vertices and E adjacency entries. Weighted edges need a different shortest-path algorithm. Our small valid graphs use vertex numbers as slice indices; production input parsing must validate those bounds.

Expected output:
2

Exercise: In the practice editor’s main.rs, replace the todo! line in shortest. Keep main and its supplied checks. Choose Run checks.

Hint 1: Initialize distance[start] = 0 and use a FIFO queue.
Hint 2: For each unseen neighbor, assign distance[vertex] + 1 before push_back. Return distance[target].

Browser experiment: In the worked program’s main.rs, replace println!("{}", shortest(&graph, 0, 4)); with let mut shorter = graph;
    shorter[0].push(4);
    println!("{}", shortest(&shorter, 0, 4));. Run again and compare. Compare the distances. How many edges are needed when there is a direct connection?
