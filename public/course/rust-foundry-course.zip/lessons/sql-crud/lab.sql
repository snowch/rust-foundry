INSERT INTO people VALUES (1, 'Ada', 90);
SELECT * FROM people;
UPDATE people SET score = 95 WHERE id = 1;
SELECT * FROM people WHERE id = 1;
DELETE FROM people WHERE id = 1;
SELECT COUNT(*) FROM people;
