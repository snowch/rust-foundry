Define the row contract

Goal: Apply the table’s name rules before accepting a row.
Before this lesson: Read and change rows with SQL; Distinguish bytes from letters; Ask a sequence for its next item

You have seen the people table and its columns. Its name rule allows 1–31 UTF-8 bytes and forbids ASCII control characters. A control character is a byte such as newline or zero that controls text handling rather than displaying a normal letter.

name.is_empty() checks for no bytes. name.bytes().any(predicate) tests whether at least one byte violates the rule. Unlike filter, any passes each byte value directly to its predicate.

Bytes below 32 and the DEL byte 127 are rejected. A positive id, a name meeting this rule, and a u32 score form a valid row; checking id uniqueness additionally needs access to the stored table.

The test helper "é".repeat(16) creates a String containing sixteen copies of that text. It occupies 32 bytes and therefore exceeds the name limit. Validation must happen before changing the database.

Expected output:
name validation passes

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Use name.len() for UTF-8 byte length.
Hint 2: Reject bytes below 32 and the DEL byte 127.

Experiment: In the lab, try an empty name and a duplicate ID separately. Verify that the earlier valid row remains.
