fn award(score: &mut u32) {
    todo!("Implement mutable")
}

fn main() {
    let mut score = 10;
    award(&mut score);
    assert_eq!(score, 15);
    award(&mut score);
    assert_eq!(score, 20);
    println!("{score}");
}
