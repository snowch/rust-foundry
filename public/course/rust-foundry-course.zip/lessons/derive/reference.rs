#[derive(Debug, PartialEq, Clone)]
struct Score { value: u32 }

fn main() {
    let first = Score { value: 90 };
    let second = first.clone();
    assert_eq!(first, second);
    println!("{second:?}");
}
