Insertion sort and a sorted-prefix invariant

Goal: Sort a mutable slice while preserving a sorted prefix after every insertion.
Before this lesson: Implement binary search; Change through one mutable borrow

Insertion sort takes the next unsorted item and inserts it into a sorted prefix. Before iteration i, values[..i] is sorted. The saved key is values[i].

Move larger prefix elements one slot to the right until the gap belongs to the key. Test j > 0 before reading values[j − 1], then put the saved key at j.

Shifting strictly greater values preserves the relative order of equal values, so this algorithm is stable. It changes the borrowed slice in place and uses O(1) auxiliary space.

Already sorted input requires O(n) time. Reverse-sorted input shifts 1 + 2 + … + (n−1) items, giving O(n²) worst-case time. The assertions cover duplicates, negative values, and an empty slice.

Expected output:
[1, 2, 5, 7, 9]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Loop i from 1 to values.len(), saving values[i] as key.
Hint 2: Shift while j > 0 and values[j - 1] > key, decrement j, then write the key at j.

Experiment: Count shifts for sorted and reverse-sorted arrays of the same length.
