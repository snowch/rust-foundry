Keep sorted, unique rows

Goal: Keep a vector sorted while rejecting duplicate keys.
Before this lesson: Transform without taking ownership; Separate success from failure

An invariant is a rule kept true after every operation. Here keys must remain sorted and unique. That lets binary_search search the ordered values efficiently.

keys.binary_search(&key) returns Ok(index) when the key exists, or Err(index) containing where a missing key belongs. This Result uses Err for a not-found position rather than a text error.

Vec::insert(index, value) inserts at that position and shifts later elements. Appending with push would be wrong for a key that belongs in the middle.

The function checks the search result before changing keys, preserving the state if the requested key is already present.

Expected output:
[1, 3, 5]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Match binary_search instead of doing a second scan.
Hint 2: Use Vec::insert at the missing key’s insertion position.

Experiment: Insert a key before the first element and after the last element, checking sorted order each time.
