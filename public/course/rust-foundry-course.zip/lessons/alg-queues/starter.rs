use std::collections::VecDeque;

fn serve(queue: &mut VecDeque<i32>) -> Option<i32> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let mut queue = VecDeque::new();
    assert_eq!(serve(&mut queue), None);
    queue.push_back(10); queue.push_back(20);
    assert_eq!(serve(&mut queue), Some(10));
    queue.push_back(30);
    assert_eq!(serve(&mut queue), Some(20));
    assert_eq!(serve(&mut queue), Some(30));
    assert_eq!(serve(&mut queue), None);
    println!("10 20 30");
}
