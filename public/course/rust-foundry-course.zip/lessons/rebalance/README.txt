Split, merge, and preserve invariants

When a leaf overflows, split its sorted rows into two leaves, link the new right leaf into the leaf chain, and insert its first key into the parent. A parent can overflow too, causing a branch split or a new root.

Deletion must restore minimum occupancy by borrowing from a sibling or merging pages. TinyDB updates separators, reuses freed page IDs, and collapses a one-child root. .check validates ordering, occupancy, equal leaf depth, reachability, and leaf links.

Expected output:
[1, 3] | 5 | [5, 7, 9]

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use split_off at the middle index.
Hint 2: The separator is right[0]; do not remove it.

Experiment: Delete the largest two keys in the lab, then inspect root collapse and free pages.
