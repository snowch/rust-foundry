Clone deliberately

Goal: Make an explicit independent copy of owned text.
Before this lesson: Small values can Copy

A move transfers ownership. .clone() explicitly creates a separate owned value. For a String, that means independent text storage.

The function clones original into changed, then appends to changed. original keeps its contents, as the checks show.

The tuple returns the two independent owners together. Only changed needs mut, because only that local value is edited.

Expected output:
Ada / Ada Jr

Exercise: In the practice editor’s main.rs, replace the todo! line in keep_and_change. Keep main and its supplied checks. Choose Run checks.

Hint 1: Clone original before changing the second value.
Hint 2: Only changed needs to be declared mut.

Browser experiment: In the worked program’s main.rs, replace println!("{} / {}", pair.0, pair.1); with println!("{} / {}", pair.1, pair.0);. Run again and compare. Compare the two texts. Which contains the appended suffix regardless of its position on the line?
