Your first Rust program

Goal: Run a three-line program and change the message it displays.
Before this lesson: No previous programming, Rust, or SQL knowledge

A program is a set of instructions for a computer. The text you edit is its source code; main.rs is the Rust source filename shown here. This program has one instruction: display the message Hello, Rust! You do not need any previous programming experience for this lesson.

The first line, fn main() {, marks where the program begins. fn means “function”, a named group of instructions; main is the name Rust starts with. The empty parentheses mean main takes no inputs here. The opening { and closing } enclose its instructions. Keep these outer lines as they are for now.

The middle line, println!("Hello, Rust!");, displays the text between the double quotes. Write println! including its exclamation mark: it is Rust’s supplied print command. Its parentheses hold the message, and the semicolon ends the instruction. The quotes mark text in the source; they are not printed.

A compiler checks your source and translates it into a program the browser can run. Your first run downloads about 58 MB of compiler files. Later runs in the same tab reuse the prepared compiler.

Expected output:
Hello, Rust!

Exercise: In the practice editor’s main.rs, replace Change this message inside the quotation marks with Hello, Rust! Keep the ! after println and the punctuation outside the quotation marks. Choose Run checks and compare the printed line.

Hint 1: Find the line beginning with println!. The message is inside its double quotes.
Hint 2: Replace Change this message with Hello, Rust!; leave the surrounding punctuation alone.

Browser experiment: In the worked program’s main.rs, replace "Hello, Rust!" with "Hello, Ada!". Run again and compare. Read Program output. Which part of the printed line changed?
