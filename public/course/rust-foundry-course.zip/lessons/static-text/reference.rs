fn ready_message() -> &'static str {
    "Ready"
}

fn main() {
    assert_eq!(ready_message(), "Ready");
    println!("{}", ready_message());
}
