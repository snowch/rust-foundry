fn byte_len(text: &str) -> usize {
    todo!("Implement shared")
}

fn main() {
    let name = String::from("café");
    assert_eq!(byte_len(""), 0);
    assert_eq!(byte_len(&name), 5);
    println!("{} {}", byte_len(&name), name);
}
