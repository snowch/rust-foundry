One algorithm, several types

Goal: Write one ordered-slice algorithm for more than one element type.
Before this lesson: Name a behavior with a trait

You have used type arguments in Option<u32>, Vec<u32>, and parse::<u32>(). A generic function now lets you name an unspecified type parameter yourself: <T>.

The bound T: Ord requires that type to support a total ordering, so the function can compare any two values of that type. Integers and string slices support this standard trait.

values.iter().max() returns an optional reference to the largest element. The reference stays borrowed from the input slice, and an empty slice produces None.

The calls choose integer or text element types. largest::<u32>(&[]) explicitly supplies the type for an empty input, where no element would otherwise reveal it.

Expected output:
9

Exercise: In the practice editor’s main.rs, replace the todo! line in largest. Keep main and its supplied checks. Choose Run checks.

Hint 1: Iterate over borrowed elements.
Hint 2: The iterator method max already returns Option<&T>.

Browser experiment: In the worked program’s main.rs, replace println!("{}", largest(&[1, 9, 3]).unwrap()); with println!("{}", largest(&["Ada", "Lin"]).unwrap());. Run again and compare. Read the largest text. Which property lets the same helper compare both types?
