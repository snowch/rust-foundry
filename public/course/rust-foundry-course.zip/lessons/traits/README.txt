Name a behavior with a trait

A trait names behavior that multiple types can implement. A bound lets an algorithm call that behavior without knowing the concrete type.

Keep interfaces small. TinyDB separates the page representation, validation, and storage operations so each boundary has a specific contract.

Expected output:
true

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Call the trait method on both borrowed arguments.
Hint 2: Compare the returned integer IDs.

Experiment: Implement Identified for a second type and call the function with two values of it.
