Give a row a type

A struct groups fields that belong together. Named fields make the meaning of an integer clear: an id and a score are not interchangeable concepts.

A method with &self borrows the row. Returning a formatted String creates new owned output without consuming the row.

Expected output:
1 | Ada | 90

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use format! to return an owned String.
Hint 2: Read id, name, and score through the shared reference.

Experiment: Create a second Row and print both labels.
