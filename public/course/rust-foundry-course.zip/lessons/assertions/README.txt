Check a result with an assertion

Goal: Read an assertion failure and check a function on more than one input.
Before this lesson: Return a calculated value

An assertion is a check written in the program. assert_eq!(actual, expected); continues only when both values are equal. It prints nothing when the check passes.

If the values differ, the running program stops and reports an assertion failure below the code. This is a runtime failure: the compiler accepted the source, but a check failed during execution. assert!(condition); similarly checks that a boolean is true.

From this lesson onward, practice starters may contain todo!("..."). That is a deliberate stop marker for an unfinished function. Replace the marker with your implementation. It is not an instruction to print the answer.

Keep the assertions in main. They provide additional inputs and boundary cases, so passing means more than matching one displayed example.

Expected output:
checks passed

Exercise: Replace todo! with an expression that doubles value. Keep both assertions in main.

Hint 1: Use the parameter in a multiplication expression.
Hint 2: value * 2 works for both zero and three.

Experiment: Temporarily return value + 2. Which assertion fails first?
