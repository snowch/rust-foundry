Separate success from failure

Goal: Return and inspect a Result with a meaningful error.
Before this lesson: Borrow a bounded sequence; Read the lifetime of a text literal

Option says a value may be missing. Result says an operation may succeed or fail with a reason. Result<u32, &'static str> stores either Ok(number) or Err(message). The two type arguments specify the successful value and error types.

A recoverable failure is returned as data, so the caller can choose what to do. A positive-id rule can reject zero without stopping the whole program.

Result methods is_ok() and is_err() inspect which variant is present. unwrap() returns an Ok value but stops on Err; it is used in worked examples only for inputs whose success has been established by the shown checks.

The if/else here is also an expression: its chosen arm produces Ok(id) or Err(message) as the function’s returned Result. Both arms produce the same Result type.

Expected output:
7

Exercise: Return Err with the shown message for zero, and Ok(id) otherwise.

Hint 1: Use the existing zero comparison to choose a Result variant.
Hint 2: Return Err("id must be positive") for zero and Ok(id) otherwise.

Experiment: Use match at the call site to print the error for zero instead of unwrapping it.
