use std::fs;

fn main() -> std::io::Result<()> {
    let bytes: [u8; 3] = [65, 66, 67];
    fs::write("sample.bin", bytes)?;
    let reopened = fs::read("sample.bin")?;
    assert_eq!(reopened, bytes);
    println!("{} bytes reopened", reopened.len());
    Ok(())
}
