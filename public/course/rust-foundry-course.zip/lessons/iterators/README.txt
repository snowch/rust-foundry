Transform without taking ownership

An iterator describes a sequence of steps. filter keeps matching items, map transforms them, and sum consumes the iterator to produce one value.

iter borrows elements, while into_iter on an owned Vec consumes it. Choose deliberately when a caller must keep using its collection.

Expected output:
140 from 3 scores

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Borrow scores with iter and copy each small integer.
Hint 2: Filter on >= 50, then sum.

Experiment: Replace sum with collect::<Vec<_>>() and inspect the retained values.
