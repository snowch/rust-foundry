fn byte_count(records: usize, size: usize) -> Option<usize> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(byte_count(3, 40), Some(120));
    assert_eq!(byte_count(usize::MAX, 40), None);
    println!("{}", byte_count(3, 40).unwrap());
}
