fn rollback(staged: &mut Option<Vec<u32>>) {
    *staged = None;
}

fn main() {
    let committed = vec![1];
    let mut staged = Some(vec![1, 2, 3]);
    rollback(&mut staged);
    assert!(staged.is_none());
    assert_eq!(committed, [1]);
    println!("{committed:?}; staged: {staged:?}");
}
