fn pair(value: u32) -> (u32, u32) {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let result = pair(7);
    let (left, right) = result;
    assert_eq!((left, right), (7, 8));
    println!("{result:?}");
}
