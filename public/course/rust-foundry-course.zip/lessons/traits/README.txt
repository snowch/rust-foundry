Name a behavior with a trait

Goal: Define and implement a named method contract for a concrete type.
Before this lesson: Record whether a value was seen; Write a method for a struct

A trait names behaviour that a type promises to provide. trait Identified declares an id method; impl Identified for Person supplies that method for Person.

The method receives &self, just like the struct method you already wrote. The body returns the existing id field.

This first trait example uses the concrete Person type in its helper. It introduces no generic function parameters yet. The next lesson uses a trait bound to make one algorithm accept several types.

You have already seen Copy and Clone behaviour. Traits give such behaviour a name that other code can require.

Expected output:
true

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Call the trait method on both borrowed arguments.
Hint 2: Compare the returned integer IDs.

Experiment: Add a second concrete type with an id field and implement Identified for it.
