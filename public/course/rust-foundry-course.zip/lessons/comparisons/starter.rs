fn main() {
    let score: u32 = 50;
    let passes: bool = score > 50;
    let in_range = score >= 1 && score <= 100;
    println!("{passes} {in_range}");
}
