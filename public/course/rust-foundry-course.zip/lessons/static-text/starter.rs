fn ready_message() -> &'static str {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(ready_message(), "Ready");
    println!("{}", ready_message());
}
