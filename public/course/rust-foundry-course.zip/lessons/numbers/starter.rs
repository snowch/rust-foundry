fn main() {
    let score: u32 = 90;
    let bonus: u32 = 0;
    println!("{}", score + bonus);
}
