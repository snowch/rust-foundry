struct Row { score: u32 }
impl Row {
    fn passes(&self) -> bool { self.score > 50 }
}
fn main() {
    let row = Row { score: 50 };
    assert!(row.passes());
    println!("{}", row.passes());
}
