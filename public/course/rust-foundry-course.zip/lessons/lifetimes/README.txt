Describe where a borrow comes from

Goal: Explain which input references support a borrowed return value.
Before this lesson: Ask Rust to generate a trait implementation; Read the lifetime of a text literal

The static-text lesson returned a literal valid for the whole program. This function instead returns one of two borrowed inputs, whose owners may have shorter scopes.

The name 'a in <'a> is a lifetime parameter. Writing &'a str for both inputs and the output states a relationship: the returned reference must remain valid within a lifetime supported by both input borrows.

The annotation neither allocates a copy nor extends an owner’s lifetime. The comparison merely selects which already-borrowed view to return.

Equal lengths select the first input in this contract. The assertions check both the longer-text case and that tie rule.

Expected output:
Grace

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Compare byte lengths without moving either input.
Hint 2: Return a on ties and b only when it is longer.

Experiment: Call longer inside a nested scope containing one input owner. Check where the returned borrow can still be used.
