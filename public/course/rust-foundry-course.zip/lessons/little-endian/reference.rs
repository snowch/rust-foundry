fn encode_id(id: u32) -> [u8; 4] {
    id.to_le_bytes()
}

fn main() {
    assert_eq!(encode_id(0), [0, 0, 0, 0]);
    assert_eq!(encode_id(0x12345678), [0x78, 0x56, 0x34, 0x12]);
    assert_eq!(u32::from_le_bytes(encode_id(u32::MAX)), u32::MAX);
    println!("{:?}", encode_id(258));
}
