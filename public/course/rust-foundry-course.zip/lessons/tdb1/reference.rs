fn legacy_count(bytes: &[u8]) -> Result<usize, &'static str> {
    if bytes.len() < 8 || &bytes[..4] != b"TDB1" || bytes[4] != 1 || bytes[5] != 40 || bytes[7] != 0 { return Err("bad header"); }
    let count = bytes[6] as usize;
    if count > 128 || bytes.len() != 8 + count * 40 { return Err("bad length"); }
    Ok(count)
}

fn main() {
    let mut bytes = vec![84, 68, 66, 49, 1, 40, 1, 0];
    bytes.extend([0; 40]);
    assert_eq!(legacy_count(&bytes), Ok(1));
    assert!(legacy_count(&bytes[..47]).is_err());
    println!("{} row header", legacy_count(&bytes).unwrap());
}
