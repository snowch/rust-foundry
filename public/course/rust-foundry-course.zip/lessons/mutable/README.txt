Change through one mutable borrow

Goal: Change a caller’s integer through one exclusive reference.
Before this lesson: Read a String without taking it; Change a value with mut

A shared reference supplies read access. &mut supplies exclusive access so a helper can change a value while the caller remains its owner.

The declaration fn award(score: &mut u32) accepts a mutable reference. The call uses &mut score to lend that access. The caller’s binding must itself be mut.

*score means the integer behind the reference. *score += 5 changes that integer; it does not reassign the reference to a different integer.

The two calls work because their exclusive borrows do not overlap. The first call finishes before the second borrow begins.

Expected output:
20

Exercise: In the practice editor’s main.rs, replace the todo! line in award. Keep main and its supplied checks. Choose Run checks.

Hint 1: Dereference the parameter to reach its u32.
Hint 2: Add five to the referenced integer.

Browser experiment: In the worked program’s main.rs, replace println!("{score}"); with award(&mut score);
    println!("{score}");. Run again and compare. Compare the printed scores. How much did the third call add to the caller’s value?
