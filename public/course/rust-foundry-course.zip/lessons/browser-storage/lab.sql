INSERT INTO people VALUES (1, 'Ada', 90);
.snapshot backup.rdb
.export exchange.tdb
SELECT * FROM people;
