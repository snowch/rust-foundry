Stage changes before publishing

Goal: Keep a committed collection unchanged while editing a candidate copy.
Before this lesson: Find your way around the complete source; Validate before you mutate

A transaction groups changes into one publish decision. Committed state is the last accepted version. Staged state is a candidate version that may still be committed or discarded.

TinyDB begins by cloning its current database. The small helper below uses .to_vec() to make an owned copy of a borrowed slice, then changes only that copy.

BEGIN starts the candidate, and reads in the same session see its staged changes. The next lessons show rollback and commit. This bounded design copies state for clarity rather than providing concurrent database sessions.

Each browser Run starts a fresh process. BEGIN and its COMMIT or ROLLBACK must therefore appear in the same script; an open transaction rolls back when that input ends.

Expected output:
committed [1, 2]; staged [1, 2, 3]

Exercise: In the practice editor’s main.rs, replace the todo! line in stage. Keep main and its supplied checks. Choose Run checks.

Hint 1: Create an owned Vec from the borrowed slice.
Hint 2: Append to the candidate, not the original.

Browser experiment: In the worked program’s main.rs, replace println!("committed {committed:?}; staged {candidate:?}"); with let candidate = stage(&committed, 4);
    println!("committed {committed:?}; staged {candidate:?}");. Run again and compare. Compare both lists. Which version has the newly supplied value?
