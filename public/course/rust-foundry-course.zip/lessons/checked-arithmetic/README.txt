Turn overflow into a result

Goal: Convert a failed checked calculation into a recoverable error.
Before this lesson: Report a recoverable error

A numeric type has a largest representable value. Adding beyond it is overflow. u32::MAX is the named largest u32 value; :: also selects constants associated with a type.

checked_add returns Some(sum) when the sum fits and None when it does not. That makes the exceptional case explicit instead of relying on how an unchecked calculation happens to run.

.ok_or(message) converts Some(value) into Ok(value), or None into Err(message). It connects an optional calculation with an error-reporting function.

Expected output:
42

Exercise: Use checked_add and convert its Option into Result with the error message overflow.

Hint 1: Start with a.checked_add(b).
Hint 2: Append .ok_or("overflow") to turn the Option into Result.

Experiment: Check u32::MAX plus zero and compare it with plus one.
