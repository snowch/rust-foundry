fn valid_name(name: &str) -> bool {
    todo!("Implement row-validation")
}

fn main() {
    assert!(valid_name("café"));
    assert!(!valid_name(""));
    assert!(!valid_name("Ada\n"));
    assert!(!valid_name(&"é".repeat(16)));
    println!("name validation passes");
}
