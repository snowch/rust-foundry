fn add_text(a: &str, b: &str) -> Result<u32, &'static str> {
    let a = a.parse::<u32>().map_err(|_| "bad number")?;
    let b = b.parse::<u32>().map_err(|_| "bad number")?;
    a.checked_add(b).ok_or("overflow")
}

fn main() {
    assert_eq!(add_text("x", "2"), Err("bad number"));
    assert_eq!(add_text("4294967295", "1"), Err("overflow"));
    assert_eq!(add_text("19", "23"), Ok(42));
    println!("{}", add_text("19", "23").unwrap());
}
