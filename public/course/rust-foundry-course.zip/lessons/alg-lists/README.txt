Linked lists and owned links

Goal: Prepend a heap-allocated node without copying or losing the existing list.
Before this lesson: Recursive algorithms and stack cost; Give a row a type; Missing is a value

A singly linked list stores a value and a link to the next node. Option<Box<Node>> is either an owned successor or None at the tail. Box owns a heap-allocated value and has a known pointer-sized representation, allowing a recursive Node type to have finite size.

Box::new creates the allocation. To prepend, head.take() moves the old Option out and leaves None in its place. Store that old head as the new node’s next link, then assign the new boxed node to head.

Traversal should borrow rather than consume the list. as_deref converts an optional owned box into an optional reference to its node. Follow node.next.as_deref() to inspect the successor without moving it.

Prepending takes O(1) time; a complete traversal takes O(n). Nodes use O(n) heap space. A Vec usually has better locality and fewer allocations, so a linked list is not a default performance improvement. This small example also avoids deep recursive destruction.

Expected output:
[3, 2, 1]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Use head.take() to move out the previous Option.
Hint 2: Assign Some(Box::new(Node { value, next: previous })) through *head.

Experiment: Append a duplicate value and confirm that a list preserves it rather than acting like a set.
