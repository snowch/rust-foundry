Save files without overwriting another tab

Goal: Distinguish a database commit from publishing a browser workspace snapshot.
Before this lesson: Replay once, verify on repetition

A process is one running copy of a program. When it finishes normally, it returns an exit code: zero for success or a nonzero number for an error. A runtime trap means execution could not continue normally, such as a failed assertion in this browser build.

The Rust program runs with a private virtual filesystem: an in-memory set of filenames and bytes supplied for this Run. A normal exit returns its complete file set to the webpage.

The webpage stores that set in IndexedDB, a browser-provided local database separate from TinyDB itself. A workspace revision counts successful whole-file-set saves, including reads that create or recover files. It is separate from TinyDB’s committed generation.

Saving compares the expected revision with the current revision inside one atomic browser storage transaction: either the complete new set is saved, or none of that save is published. A stale tab keeps its unsaved candidate downloadable rather than overwriting another tab.

An ordinary nonzero process exit can include earlier successful commits. Stop, traps, or timeouts return no candidate snapshot and keep the previous saved files. Browser storage can be denied or evicted, so download important files.

This explains the recovery lab boundary: a deliberate .crash exit can save the journal plus main file together, while an actual tab termination during the Run leaves the prior IndexedDB snapshot. No JavaScript or operating-system knowledge is required to use these rules.

Expected output:
4

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Reject when expected and current differ.
Hint 2: Increment only the matching revision with checked arithmetic.

Experiment: Open the workspace in two tabs, save in one, and observe how a stale save in the other is blocked.
