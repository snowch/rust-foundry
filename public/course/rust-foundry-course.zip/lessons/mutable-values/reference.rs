fn main() {
    let mut score = 10;
    score += 5;
    score += 5;
    println!("{score}");
}
