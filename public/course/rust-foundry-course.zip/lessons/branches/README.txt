Choose which instruction runs

Goal: Use if and else to choose between two instructions.
Before this lesson: Ask a true-or-false question

if runs a block only when its condition is true. An else block supplies the alternative when that condition is false. Exactly one of these two blocks runs.

The condition is a bool expression you already know how to write. Braces enclose each block just as they enclose main.

This example prints one of two messages directly. You do not need a function that returns text, a text-reference type, or a lifetime annotation.

Expected output:
pass

Exercise: Fix the comparison so a score of 50 selects the pass block.

Hint 1: Revisit the comparison lesson if equality is confusing.
Hint 2: The condition needs score >= 50.

Experiment: Change score to 49 and predict the selected block.
