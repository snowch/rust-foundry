Rollback discards the candidate

ROLLBACK drops staged state and preserves committed state. It must undo all successful changes in that transaction, not merely the last statement.

A failed SQL statement leaves its previous staged state intact. TinyDB keeps the transaction active after a statement error so the learner can inspect it and choose rollback. It does not implement PostgreSQL’s aborted-transaction behavior.

Expected output:
[1]; staged: None

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Replace the Option itself, through the mutable reference.
Hint 2: Assign None to *staged.

Experiment: Stage an update and a delete, then rollback and inspect both original rows.
