Borrow a bounded sequence

Goal: Handle an empty slice without indexing past its bounds.
Before this lesson: Missing is a value

Direct values[0] indexing assumes an element exists. .first() instead returns Some(reference) for the first element or None for an empty slice.

The helper matches that Option. Some(value) contains a reference, so *value reads the u32. The None arm supplies zero as the chosen fallback.

This reuses slice borrowing and enum matching. It avoids .copied() and iterator pipelines until their own lessons.

Expected output:
9

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Match the Option returned by values.first().
Hint 2: Return *value for Some(value), or zero for None.

Experiment: Pass &values[2..2] and predict which arm runs.
