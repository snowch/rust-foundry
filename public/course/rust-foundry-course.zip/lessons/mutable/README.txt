Change through one mutable borrow

Goal: Change a caller’s integer through one exclusive reference.
Before this lesson: Read a String without taking it; Change a value with mut

A shared reference supplies read access. &mut supplies exclusive access so a helper can change a value while the caller remains its owner.

The declaration fn award(score: &mut u32) accepts a mutable reference. The call uses &mut score to lend that access. The caller’s binding must itself be mut.

*score means the integer behind the reference. *score += 5 changes that integer; it does not reassign the reference to a different integer.

The two calls work because their exclusive borrows do not overlap. The first call finishes before the second borrow begins.

Expected output:
20

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Dereference the parameter to reach its u32.
Hint 2: Add five to the referenced integer.

Experiment: Call award a third time and predict the caller’s score before changing the final assertion.
