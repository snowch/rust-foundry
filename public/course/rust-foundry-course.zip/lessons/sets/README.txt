Record whether a value was seen

Goal: Use a HashSet to distinguish a new value from a repeated one.
Before this lesson: Count with a map

A map associates keys with values. A set records only whether each value is present. HashSet<u32> therefore stores unique integers without a separate associated value.

HashSet::new() creates an empty set. insert(value) returns true if it added a new member, and false if that member was already present. contains(&value) checks membership.

TinyDB later uses a set of visited page IDs to reject a page-link cycle: encountering a page twice can signal an invalid file. Set iteration order, like hash-map order, is unspecified.

Expected output:
1

Exercise: Make the second insertion repeat seven so it reports an existing member and the set keeps one value.

Hint 1: The duplicate must have the same value as the first insertion.
Hint 2: Change the second inserted value from eight to seven.

Experiment: Insert eight after the duplicate check and predict the new length.
