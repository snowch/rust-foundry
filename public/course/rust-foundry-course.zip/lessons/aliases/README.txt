Give a recurring type a readable name

Goal: Use a generic type alias for a repeated Result type.
Before this lesson: Ask Rust to generate a trait implementation; Separate success from failure

A type alias gives an existing type another name. type DbResult<T> = Result<T, String>; says that DbResult uses a String error while T still chooses the success type.

For example, DbResult<u32> means Result<u32, String>, and DbResult<()> means a result that reports success without another value. The alias creates no new storage or conversion.

pub before an item makes it public, so another module can use it. Items without pub are private to their module by default. The full TinyDB source uses public Row, Database, and Session operations with private helpers.

Expected output:
7

Exercise: Implement positive using the alias: return a String error for zero and Ok(value) otherwise.

Hint 1: The zero case needs Err(String::from("zero")).
Hint 2: The other case returns Ok(value).

Experiment: Write a second function returning DbResult<()> and return Ok(()) on success.
