fn largest<T: Ord>(values: &[T]) -> Option<&T> {
    values.iter().max()
}

fn main() {
    assert_eq!(largest::<u32>(&[]), None);
    assert_eq!(largest(&[1, 9, 3]), Some(&9));
    assert_eq!(largest(&["Ada", "Lin"]), Some(&"Lin"));
    println!("{}", largest(&[1, 9, 3]).unwrap());
}
