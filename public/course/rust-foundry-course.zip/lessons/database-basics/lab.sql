.tables
.schema
.check
