fn search(values: &[i32], target: i32) -> Option<usize> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let values = [2, 5, 8, 12, 16, 23, 38, 56];
    assert_eq!(search(&values, 2), Some(0));
    assert_eq!(search(&values, 56), Some(7));
    assert_eq!(search(&values, 13), None);
    assert_eq!(search(&[], 1), None);
    assert_eq!(search(&[9], 9), Some(0));
    println!("{}", search(&values, 23).unwrap());
}
