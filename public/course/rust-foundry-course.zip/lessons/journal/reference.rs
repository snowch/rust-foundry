fn recovery_action(committed: bool) -> &'static str {
    if committed { "redo" } else { "discard" }
}

fn main() {
    assert_eq!(recovery_action(false), "discard");
    assert_eq!(recovery_action(true), "redo");
    println!("prepared: {}; committed: {}", recovery_action(false), recovery_action(true));
}
