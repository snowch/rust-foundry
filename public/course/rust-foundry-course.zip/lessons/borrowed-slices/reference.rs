fn total(values: &[u32]) -> u32 {
    let mut result = 0;
    for value in values { result += *value; }
    result
}

fn main() {
    let values = [10, 20, 30];
    assert_eq!(total(&values[1..3]), 50);
    assert_eq!(total(&[]), 0);
    println!("{}", total(&values));
}
