Return a calculated value

Goal: Use a function’s return value in a later calculation.
Before this lesson: Pass a value into a function; Calculate before printing

A function can produce a value for its caller. -> u32 after the parameters means this function returns a u32. The arrow is part of the function definition, not an arithmetic operation.

The last expression in a function becomes its return value when it has no trailing semicolon. minutes * 60 returns the calculated number. A trailing semicolon would discard that expression’s value.

Functions with no return arrow, such as our printing helpers, return (), called unit. Unit means no useful result value. This is why a discarded calculation cannot satisfy -> u32.

Expected output:
180

Exercise: Repair the returned calculation. Leave the final expression without a semicolon.

Hint 1: Use multiplication, as in the arithmetic lesson.
Hint 2: The returned expression should be minutes * 60.

Experiment: Add a semicolon after minutes * 60, read the error, then remove it.
