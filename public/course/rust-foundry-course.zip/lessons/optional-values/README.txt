Represent a missing value

Goal: Handle both Some and None with match.
Before this lesson: Represent alternatives

Option is a standard enum for a value that may be absent. Option<u32> means either Some(number), containing a u32, or None, containing no value. The angle brackets choose the type stored inside this standard container.

match handles those two variants just as it handled your own enum. Some(value) binds the contained number to value in that arm; None handles absence.

An Option also offers unwrap_or(fallback), which returns the contained value or the supplied fallback. Unlike unwrap(), unwrap_or handles None deliberately. unwrap() instead stops the program on None; use it only when presence is established, such as an assertion-controlled example.

When only the present case needs work, if let Some(value) = optional { ... } is a shorter conditional match. It runs its block once for Some and skips it for None. Use a full match when both cases need explicit actions.

Expected output:
7

Exercise: Match both variants: return the stored number for Some, and zero for None.

Hint 1: Use a match expression with one arm per variant.
Hint 2: Some(number) => number and None => 0 handle both cases.

Experiment: Compare Some(0) and None with assert_eq! or a match.
