Replay once, verify on repetition

Recovery must be idempotent: running it twice has the same effect as running it once. A committed journal targeting generation N can install over N−1; if N is already installed, its bytes must match the journal snapshot before cleanup.

A checksum detects accidental byte changes, not malicious rewriting. RDB2 and RWL2 use FNV-1a checksums together with structural validation, bounded lengths, and generation checks. They are teaching formats, not authenticated storage.

Expected output:
already installed

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Validate target == base + 1 using checked arithmetic.
Hint 2: Handle base, identical target, and conflict as three explicit cases.

Experiment: Try .crash commit and .crash install in separate lab files, then reopen each twice.
