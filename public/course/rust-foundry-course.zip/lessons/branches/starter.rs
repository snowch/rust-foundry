fn verdict(score: u32) -> &'static str {
    todo!("Implement branches")
}

fn main() {
    assert_eq!(verdict(49), "retry");
    assert_eq!(verdict(50), "pass");
    println!("{}", verdict(90));
}
