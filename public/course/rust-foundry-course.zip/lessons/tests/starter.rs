fn round_trip(values: &[u32]) -> bool {
    todo!("Implement tests")
}

fn main() {
    assert!(round_trip(&[]));
    assert!(round_trip(&[0, 1, 255, 256, 65535, u32::MAX]));
    println!("round trips pass");
}
