fn parse_id(text: &str) -> Result<u32, &'static str> {
    match text.parse::<u32>() {
        Ok(id) if id > 0 => Ok(id),
        _ => Err("expected a positive u32"),
    }
}

fn main() {
    assert!(parse_id("0").is_err());
    assert!(parse_id("-1").is_err());
    assert!(parse_id("4294967296").is_err());
    assert_eq!(parse_id("42"), Ok(42));
    println!("{}", parse_id("42").unwrap());
}
