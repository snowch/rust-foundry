Write a small operation as a value

Goal: Call a closure and recognise its parameter syntax.
Before this lesson: Use a sequence that can grow; Return a calculated value

A closure is a small function-like value. |value: u32| value + 5 takes an input and produces an output, much like the function you wrote earlier.

The vertical bars delimit its parameters. Its final expression is the result. Store it with let add_five = ...; and call it with add_five(10). Rust can often infer parameter types when the calling method already specifies them.

A closure can also use a surrounding value; this is called capturing. Later iterator methods accept closures to choose or transform elements.

Expected output:
15

Exercise: Make the closure add the captured bonus to its parameter.

Hint 1: The captured bonus is already available by name.
Hint 2: The closure body should be value + bonus.

Experiment: Change the bonus and predict the returned value.
