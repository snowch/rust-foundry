type DbResult<T> = Result<T, String>;

fn positive(value: u32) -> DbResult<u32> {
    if value == 0 { Err(String::from("zero")) } else { Ok(value) }
}

fn main() {
    assert!(positive(0).is_err());
    assert_eq!(positive(7), Ok(7));
    println!("{}", positive(7).unwrap());
}
