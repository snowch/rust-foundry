enum Command { Count, Lookup(u32) }

fn describe(command: Command) -> String {
    match command {
        Command::Count => String::from("count all rows"),
        Command::Lookup(id) => format!("lookup {id}"),
    }
}

fn main() {
    assert_eq!(describe(Command::Count), "count all rows");
    assert_eq!(describe(Command::Lookup(7)), "lookup 7");
    println!("{}", describe(Command::Lookup(42)));
}
