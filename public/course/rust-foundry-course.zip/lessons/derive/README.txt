Ask Rust to generate a trait implementation

Goal: Use derive to inspect, compare, and clone a simple struct.
Before this lesson: One algorithm, several types

An attribute supplies an instruction about the item below it. #[derive(Debug, PartialEq, Clone)] asks Rust to generate implementations of those traits for the following struct, when its fields support them.

Debug enables {:?} inspection. PartialEq enables equality comparisons, including assert_eq!. Clone enables an explicit .clone(). You have used these behaviours on standard types; now your own type can support them too.

This does not automatically make the type Copy. A struct containing a String still owns text and needs an explicit clone to make a separate owner.

Expected output:
Score { value: 90 }

Exercise: Set the stored score to ninety and keep the derived traits and clone check.

Hint 1: The field value controls the displayed score.
Hint 2: Set value: 90 in the Score construction.

Experiment: Remove Debug from derive and inspect the compiler’s explanation of the formatting failure.
