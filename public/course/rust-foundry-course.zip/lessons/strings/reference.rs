fn greeting() -> String {
    let mut name = String::from("Ada");
    name.push_str("!");
    name
}

fn main() {
    assert_eq!(greeting(), "Ada!");
    println!("{}", greeting());
}
