fn passing_total(scores: &[u32]) -> u32 {
    todo!("Implement iterators")
}

fn main() {
    let scores = vec![10, 50, 90];
    assert_eq!(passing_total(&[]), 0);
    assert_eq!(passing_total(&scores), 140);
    println!("{} from {} scores", passing_total(&scores), scores.len());
}
