Seek through a B+ tree

A branch stores separators and child page IDs. Each separator equals the smallest key in its right child. To search for a key, choose the child after every separator less than or equal to it.

Leaves contain the actual rows, sorted by unique id. A point lookup follows one root-to-leaf path; a range query seeks its lower bound and then walks linked leaves. EXPLAIN reports the actual search path in the workspace.

Expected output:
child 1

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Count the separators that are <= the requested key.
Hint 2: partition_point finds that boundary in sorted separators.

Experiment: Compare EXPLAIN for a missing key, a present key, and a bounded range.
