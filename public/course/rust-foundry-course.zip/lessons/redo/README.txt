Replay once, verify on repetition

Goal: Replay a committed after-image once and verify it safely on another recovery attempt.
Before this lesson: Record intent before installing pages

Idempotent means repeating an operation has the same effect as doing it once. Recovery needs this property because an interruption may happen after pages are installed but before journal cleanup.

A committed journal targeting generation N can install over its base generation N−1. If N is already installed, the exact snapshot bytes must match before removing the journal.

Matching generation numbers alone do not prove matching data. A different generation or different bytes are a conflict: report the error and retain the files rather than guessing which state to keep.

Checksums detect accidental byte changes, while structural validation checks the tree rules. Neither check authenticates a file against deliberate rewriting.

Expected output:
already installed

Exercise: In the practice editor’s main.rs, replace the todo! line in redo_decision. Keep main and its supplied checks. Choose Run checks.

Hint 1: Validate target == base + 1 using checked arithmetic.
Hint 2: Handle base, identical target, and conflict as three explicit cases.

Browser experiment: In the worked program’s main.rs, replace println!("{}", redo_decision(5, 4, 5, true).unwrap()); with println!("{:?}", redo_decision(5, 4, 5, false));. Run again and compare. Read the Result. Why does matching the generation alone fail to show that the installed contents match?
