Report a recoverable error

Goal: Parse a positive numeric ID and distinguish parsing from validation.
Before this lesson: Separate success from failure

Parsing means interpreting text as a value. text.parse::<u32>() asks the standard parser for a u32. The ::<u32> chooses the method’s output type; angle brackets specify a type rather than a runtime input value.

parse returns Result because malformed text, negative numbers, or a number too large for u32 cannot produce this value. An Err(_) pattern ignores the parser’s detailed error when you want your own message.

Parsing is different from a domain rule: zero parses as u32, but TinyDB IDs must be positive. Ok(id) if id > 0 is a guarded match arm; the condition must also be true for that arm to match.

The function returns one fixed error message for every rejected input. Its &'static str error type is the literal-text reference you have already learned.

Expected output:
42

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: First parse the text into u32.
Hint 2: Accept only Ok(id) where id > 0.

Experiment: Add checks for surrounding whitespace and leading zeroes, then document which strings the standard parser accepts.
