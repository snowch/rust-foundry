Save files without overwriting another tab

Each browser Run gets a private virtual filesystem. After a normal exit, the host saves the complete resulting file set in one IndexedDB transaction. Traps, Stop, and timeouts keep the previous saved files; an ordinary nonzero exit can still contain earlier successful commits.

The save compares the revision read at startup with the current revision inside the same read/write transaction. A stale tab cannot overwrite newer files. Its unsaved files remain downloadable. Browser storage may be evicted or denied, so export files you want to keep.

Expected output:
4

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Reject when expected and current differ.
Hint 2: Increment only the matching revision with checked arithmetic.

Experiment: Open the workspace in two tabs, save in one, then attempt a write in the other.
