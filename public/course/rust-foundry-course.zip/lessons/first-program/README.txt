Your first Rust program

Goal: Run a three-line program and change the message it displays.
Before this lesson: No previous programming, Rust, or SQL knowledge

A program is a set of instructions for a computer. The text you edit is its source code; main.rs is the Rust source filename shown here. This program has one instruction: display the message Hello, Rust! You do not need any previous programming experience for this lesson.

The first line, fn main() {, marks where the program begins. fn means “function”, a named group of instructions; main is the name Rust starts with. The empty parentheses mean main takes no inputs here. The opening { and closing } enclose its instructions. Keep these outer lines as they are for now.

The middle line, println!("Hello, Rust!");, displays the text between the double quotes. Write println! including its exclamation mark: it is Rust’s supplied print command. Its parentheses hold the message, and the semicolon ends the instruction. The quotes mark text in the source; they are not printed.

Choose Run example below. A compiler is the tool that checks your source and translates it into a form the browser can run. Your output appears beneath the code. The first run downloads the compiler; later runs reuse it. Then change just the words inside the quotes and run again.

Expected output:
Hello, Rust!

Exercise: Change only the text inside the quotes to Hello, Rust! Keep the quotes, parentheses, exclamation mark, and semicolon.

Hint 1: Find the line beginning with println!. The message is inside its double quotes.
Hint 2: Replace Change this message with Hello, Rust!; leave the surrounding punctuation alone.

Experiment: Change the message to your own greeting. Predict the new output before running it.
