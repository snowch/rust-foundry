Missing is a value

Option<T> is either Some(T) or None. A failed lookup is an ordinary outcome, not necessarily a program error.

This small ordered collection is a stepping stone to an index. The function returns a borrowed row, so the caller cannot keep it after the underlying collection goes away.

Expected output:
Ada

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Search the iterator for a matching first tuple field.
Hint 2: Map a matching row to its name slice.

Experiment: Use a match at the call site to print a separate not-found message.
