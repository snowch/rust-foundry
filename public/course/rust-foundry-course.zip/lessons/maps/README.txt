Count with a map

Goal: Count repeated text keys with a HashMap entry.
Before this lesson: Find names in the standard library; Keep sorted, unique rows

A HashMap associates each key with a value. HashMap<String, u32> uses owned text as its keys and integer counts as its values. The import makes that standard type’s short name available.

.entry(key).or_insert(0) finds the key’s current value or inserts an initial zero. It returns a mutable reference to the count, which you can increment using *count += 1.

The input is a slice of borrowed text views. The loop’s word is a reference to one such view, so *word gives the &str used by String::from. This creates the owned key the map needs.

.get("rust") borrows a key to look up an optional reference to its value. As with other checked lookups, a missing key produces None. HashMap does not promise iteration order.

HashMap::new() creates the empty map. The compiler infers its key and value types from the declared return type and the later entry operations.

Expected output:
rust: 2

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Create an empty HashMap and loop over the words.
Hint 2: Increment the mutable value returned by entry(...).or_insert(0).

Experiment: Add another rust input and predict its count without relying on map iteration order.
