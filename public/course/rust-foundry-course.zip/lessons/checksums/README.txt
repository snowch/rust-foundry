Check whether bytes changed

Goal: Explain what a checksum can detect and why it is not authentication.
Before this lesson: Stop a missing calculation with ?

A checksum is a small value calculated from file bytes. Saving it alongside the data lets a reader recalculate and compare, which can reveal an accidental change.

This deliberately simple demonstration adds the bytes into a u32. u32::from(*byte) converts a u8 value to a larger integer type without losing information. wrapping_add deliberately wraps at the numeric limit; it is appropriate here only because this checksum’s rule explicitly defines that behaviour.

Different byte sequences can share a checksum. That is a collision. This toy sum gives the same result for [1, 2] and [2, 1], so matching checksums are not proof that two files are identical.

TinyDB uses a different checksum algorithm, FNV-1a, plus structural validation. Neither this toy checksum nor FNV-1a authenticates a file against deliberate tampering.

Expected output:
6

Exercise: Convert each byte to u32 and add it using the explicitly defined wrapping rule.

Hint 1: Keep the accumulator typed as u32.
Hint 2: For each byte use total.wrapping_add(u32::from(*byte)).

Experiment: Change one byte in [1, 2, 3] and then swap two bytes. Compare what this toy checksum detects.
