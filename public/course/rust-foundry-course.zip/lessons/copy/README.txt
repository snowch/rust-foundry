Small values can Copy

Goal: Distinguish copying a u32 from moving an owned String.
Before this lesson: Follow a moved String; Return two values together

Assigning a u32 makes another usable copy of that number. Rust calls this behaviour Copy. You can use both integer bindings after the assignment.

This is a property of a type, not an exception to the String ownership rule. String does not have Copy behaviour; an assignment of a String transfers its ownership.

The worked function returns a tuple, whose construction and destructuring you have already practised. Both elements remain usable because the integers were copied.

Expected output:
7 7

Exercise: In the practice editor’s main.rs, replace the todo! line in twice. Keep main and its supplied checks. Choose Run checks.

Hint 1: Assign value to another binding.
Hint 2: Return a tuple containing both bindings.

Browser experiment: In the worked program’s main.rs, replace println!("{a} {b}"); with println!("{a} {b} {a}");. Run again and compare. Read the three numbers. Which binding is still usable after its number is assigned to the other binding?
