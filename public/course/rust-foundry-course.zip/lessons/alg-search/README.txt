Implement binary search

Goal: Shrink a sorted half-open interval until a target is found or the interval is empty.
Before this lesson: Big O: time, space, and input cases; Represent a missing value; Borrow part of an array

The earlier sorted-vector lesson used the library’s binary_search. Here implement the search itself. A sorted slice lets each comparison rule out half of the remaining candidates.

Track a half-open interval [lo, hi): lo is included and hi is excluded. Initially it spans 0..values.len(). While lo < hi, mid = lo + (hi − lo) / 2 is a valid index.

An equal value returns Some(mid). A smaller middle value moves lo to mid + 1; a larger middle value moves hi to mid. Both updates strictly shrink the interval, including when the slice is empty or has one element.

Each step halves the candidate count, giving O(log n) worst-case time and O(1) auxiliary space. The input must be sorted. With duplicates, this implementation can return any matching position, not necessarily the first.

Expected output:
5

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Use lo = 0 and hi = values.len(); continue while lo < hi.
Hint 2: Return on equality, move lo to mid + 1 for a smaller middle value, otherwise set hi = mid.

Experiment: Add tests for targets below the minimum and above the maximum. Then investigate which duplicate position is returned.
