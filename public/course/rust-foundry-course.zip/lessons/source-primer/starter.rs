type DbResult<T> = Result<T, String>;

struct Session { committed: u32 }
impl Session {
    fn read(&self) -> DbResult<u32> { todo!("Read the supplied field") }
}
fn main() {
    let session = Session { committed: 7 };
    assert_eq!(session.read(), Ok(7));
    println!("{}", session.read().unwrap());
}
