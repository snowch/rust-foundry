fn sum_items(values: &[u32]) -> u32 {
    let mut items = values.iter();
    let mut total = 0;
    while let Some(value) = items.next() { total += *value; }
    total
}

fn main() {
    assert_eq!(sum_items(&[]), 0);
    assert_eq!(sum_items(&[1, 2, 3]), 6);
    println!("{}", sum_items(&[1, 2, 3]));
}
