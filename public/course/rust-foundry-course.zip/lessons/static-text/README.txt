Read the lifetime of a text literal

Goal: Recognise why a function can return a view of literal text.
Before this lesson: Read a view of text with &str; Notice where a name is usable

A lifetime is the period for which a reference is valid. References must not be used after the data they refer to is gone.

Literal text is part of the program itself, so a view of it can remain valid for the whole program. &'static str states that property. Here the apostrophe introduces the lifetime name static; it is not a character literal.

This annotation is useful for fixed error messages later. It does not mean every reference is static, and it cannot make a reference to a local String last longer. The later lifetimes lesson covers references borrowed from function inputs.

Expected output:
Ready

Exercise: Return the literal "Ready" without making a local String or printing inside the helper.

Hint 1: The returned value can be a text literal.
Hint 2: Use "Ready" as the final expression.

Experiment: Compare this return type with -> String from the owned-text lesson.
