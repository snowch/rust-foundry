Find names in the standard library

Goal: Read a standard-library path and introduce a short imported name.
Before this lesson: Transform without taking ownership

Rust’s standard library supplies reusable types and functions. std is its top-level name. A module groups related names, and :: steps through that grouping.

std::cmp::min names the min function in the cmp comparison module. use std::cmp::min; makes the short name min available in this file.

This is why later collection examples write use std::collections::HashMap;. Importing a name does not download a package: these examples use the standard library already provided by the browser compiler.

Expected output:
3

Exercise: Keep the import and change the second argument so min(7, ...) returns three.

Hint 1: The minimum of seven and three is three.
Hint 2: Use min(7, 3).

Browser experiment: In the worked program’s main.rs, replace let smaller = min(7, 3); with let smaller = std::cmp::min(7, 3);. Run again and compare. Read the printed number. What changes about locating the function when its full path is supplied?
