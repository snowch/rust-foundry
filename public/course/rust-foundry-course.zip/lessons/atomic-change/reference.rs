fn rename(name: &mut String, replacement: &str) -> Result<(), &'static str> {
    if replacement.is_empty() || replacement.len() > 31 { return Err("invalid name"); }
    *name = String::from(replacement);
    Ok(())
}

fn main() {
    let mut name = String::from("Ada");
    assert!(rename(&mut name, "").is_err());
    assert_eq!(name, "Ada");
    rename(&mut name, "Lin").unwrap();
    assert_eq!(name, "Lin");
    println!("{name}");
}
