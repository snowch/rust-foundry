fn twice(value: u32) -> (u32, u32) {
    let other = value;
    (value, other)
}

fn main() {
    assert_eq!(twice(0), (0, 0));
    let (a, b) = twice(7);
    assert_eq!((a, b), (7, 7));
    println!("{a} {b}");
}
