05-index-deletion

Prefer borrowing from a sibling with spare occupancy; otherwise merge and free the removed page.

Implement the TODO in the otherwise working database.
Native checks: rustc --edition 2021 --test starter.rs -o tinydb-tests && ./tinydb-tests
Native CLI: rustc --edition 2021 starter.rs -o tinydb && ./tinydb people.rdb
Browser: open this milestone in Rust Foundry, compile it, and install it in the workspace. Browser examples are smoke checks; use the native invariant suite for the full check.
