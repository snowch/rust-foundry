fn sum_items(values: &[u32]) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(sum_items(&[]), 0);
    assert_eq!(sum_items(&[1, 2, 3]), 6);
    println!("{}", sum_items(&[1, 2, 3]));
}
