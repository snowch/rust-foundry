Exchange files with C Foundry

Goal: Validate a documented header and its exact record length.
Before this lesson: Parse SQL without splitting names; Write and reopen bytes; Encode a number explicitly

TDB1 is an exchange format shared with C Foundry. A header is the first metadata in a file. Its magic, the bytes spelling TDB1, identifies the format; its version distinguishes compatible layouts.

The exact eight header bytes are TDB1, version 1, row size 40, a one-byte row count, and a reserved zero byte. The count may be at most 128. After the header, each record has id (4 bytes), a zero-terminated UTF-8 name field (32 bytes), and score (4 bytes). Integer fields use little-endian order.

In Rust, b"TDB1" is a byte-string literal: the ASCII letter codes as bytes rather than a text slice. bytes[6] as usize converts the small count byte to the length/index type. This widening conversion is safe for u8; arbitrary narrowing casts would need their own validation.

The whole file must have exactly 8 + count * 40 bytes. This exercise checks only that outer contract. The full Rust decoder also validates each row and rejects duplicate IDs. .export creates a separate TDB1 file; .import accepts it after validation.

In the test setup, bytes.extend([0; 40]) appends forty zero bytes after the header. extend appends a whole sequence; [0; 40] repeats the array element using the notation from the arrays lesson.

The workspace command .export exchange.tdb writes a separate exchange file. .snapshot backup.rdb instead writes a copy in TinyDB’s paged format. Use a different filename from the active database; download the resulting file from the workspace file list.

Expected output:
1 row header

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Validate the eight-byte header before reading count.
Hint 2: Check bytes.len() == 8 + count * 40 and count <= 128.

Experiment: Download exchange.tdb, reopen it in C Foundry, and compare the displayed rows.
