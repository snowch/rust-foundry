One algorithm, several types

A generic function describes behavior shared by many types. Ord supplies an ordering contract, so the same maximum operation can compare integers or string slices.

Returning a reference avoids requiring Clone. The result is borrowed from the input slice and cannot outlive it.

Expected output:
9

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Iterate over borrowed elements.
Hint 2: The iterator method max already returns Option<&T>.

Experiment: Try largest with f64 values and read the trait-bound error.
