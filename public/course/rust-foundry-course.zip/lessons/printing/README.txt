Run instructions in order

Goal: Predict and print two lines in the order they are written.
Before this lesson: Your first Rust program

Rust follows the instructions in main from top to bottom. Two println! instructions produce two separate lines in that same order.

A newline means moving to the next output line. println! adds one after its message, so you do not need to put a line break inside the quotes.

Use a new source line and a semicolon for each instruction. Indentation—the spaces before each instruction—helps you see what is inside main.

Expected output:
First
Second

Exercise: Reorder the two print instructions so First appears before Second.

Hint 1: Move whole println! lines, including their semicolons.
Hint 2: Put println!("First"); before println!("Second");.

Experiment: Add a third line, then predict the complete three-line output.
