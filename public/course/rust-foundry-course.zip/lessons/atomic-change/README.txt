Validate before you mutate

Goal: Keep a previous value intact when a replacement is rejected.
Before this lesson: Propagate with ?; Change through one mutable borrow

A failed change should leave the previous valid state intact. First validate the proposed replacement; only assign it after those checks succeed.

This helper uses .is_empty() to ask whether the text has no bytes, and .len() to enforce the maximum byte count. || rejects the replacement if either rule fails.

On success, String::from(replacement) creates the new owned text and *name replaces the caller’s String through its mutable reference. On failure, the early Err occurs before that assignment.

Rust’s ownership checks do not automatically give your application this failure guarantee. The order of your validation and mutation matters.

Expected output:
Lin

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Check the byte length before assigning.
Hint 2: Use replacement.to_owned() only after validation succeeds.

Experiment: Try an overlong replacement and check that the previous name remains unchanged.
