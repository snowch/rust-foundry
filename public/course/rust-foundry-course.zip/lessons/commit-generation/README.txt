Commit one new generation

COMMIT validates and publishes the entire candidate as the next database generation. A write outside an explicit transaction autocommits through the same journal protocol.

A generation records successful commits, not the number of rows or SQL statements. Multiple changes in one transaction produce one increment. Snapshot generations and browser workspace revisions are separate counters with different purposes.

Expected output:
generation 42

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Do not use wrapping_add for a persistent generation counter.
Hint 2: Return checked_add(1) directly.

Experiment: Compare .pages generation changes for two autocommits and two inserts inside one transaction.
