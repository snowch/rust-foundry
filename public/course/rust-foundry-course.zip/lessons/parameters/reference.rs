fn show_score(score: u32) {
    println!("score {score}");
}

fn main() {
    show_score(90);
    show_score(75);
}
