INSERT INTO people VALUES (1, 'Ada', 90);
SELECT * FROM people;
.schema
.check
