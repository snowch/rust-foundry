fn insert_key(keys: &mut Vec<u32>, key: u32) -> Result<(), &'static str> {
    todo!("Implement vectors")
}

fn main() {
    let mut keys = vec![1, 5];
    insert_key(&mut keys, 3).unwrap();
    assert!(insert_key(&mut keys, 3).is_err());
    assert_eq!(keys, [1, 3, 5]);
    println!("{keys:?}");
}
