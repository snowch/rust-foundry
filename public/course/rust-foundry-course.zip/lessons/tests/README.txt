Test an invariant, not one example

A round-trip test checks that decoding an encoded value returns the original. Boundary tests catch mistakes that a single friendly example misses.

In this browser, assertions in main run with the program. Native rustc --test runs the database’s larger test suite, including randomized operations compared with an independent ordered map.

Expected output:
round trips pass

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Visit every input using iter().all(...).
Hint 2: Compare from_le_bytes(value.to_le_bytes()) with the original value.

Experiment: Break the decoder’s byte order and find the smallest test value that reveals it.
