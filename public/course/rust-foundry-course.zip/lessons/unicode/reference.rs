fn main() {
    let text = "café";
    println!("{} bytes", text.len());
    for letter in text.chars() {
        println!("{letter}");
    }
}
