Own a piece of editable text

Goal: Create a String and append text to it.
Before this lesson: Store a fixed-size sequence; Pass a value into a function

The quoted text you have printed is written directly into the program. A String is a value that owns editable text. Owning means it is responsible for keeping that text available and releasing its storage when it is no longer needed.

String::from("Ada") creates an owned String containing Ada. The :: selects a function associated with the String type; from is its constructor here. This differs from a dot, which calls a method on an existing value.

name.push_str("!") calls the push_str method on name and appends text. Because the contents change, name must be declared mut. .len() reports how many bytes the text occupies; for the plain A–Z letters here, one letter occupies one byte.

Expected output:
Ada!

Exercise: Create an owned String for Ada, append ! with push_str, and return it.

Hint 1: Use let mut name = String::from("Ada");.
Hint 2: Append with name.push_str("!");, then return name without a semicolon.

Experiment: Append a second short piece of text and update the expected assertion.
