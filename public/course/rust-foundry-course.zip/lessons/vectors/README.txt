Keep sorted, unique rows

Goal: Keep a vector sorted while rejecting duplicate keys.
Before this lesson: Transform without taking ownership; Separate success from failure

An invariant is a rule kept true after every operation. Here keys must remain sorted and unique. That lets binary_search search the ordered values efficiently.

keys.binary_search(&key) returns Ok(index) when the key exists, or Err(index) containing where a missing key belongs. This Result uses Err for a not-found position rather than a text error.

Vec::insert(index, value) inserts at that position and shifts later elements. Appending with push would be wrong for a key that belongs in the middle.

The function checks the search result before changing keys, preserving the state if the requested key is already present.

Expected output:
[1, 3, 5]

Exercise: In the practice editor’s main.rs, replace the todo! line in insert_key. Keep main and its supplied checks. Choose Run checks.

Hint 1: Match binary_search instead of doing a second scan.
Hint 2: Use Vec::insert at the missing key’s insertion position.

Browser experiment: In the worked program’s main.rs, replace println!("{keys:?}"); with insert_key(&mut keys, 2).unwrap();
    println!("{keys:?}");. Run again and compare. Read the order in the new vector. Where was 2 inserted relative to 1 and 3?
