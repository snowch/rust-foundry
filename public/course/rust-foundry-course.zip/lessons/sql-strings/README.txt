Parse SQL without splitting names

The SQL lexer distinguishes keywords, numbers, punctuation, and quoted text. Splitting a statement on whitespace breaks names containing spaces; blindly splitting on semicolons breaks quoted strings.

TinyDB supports a deliberately small grammar, including INSERT, SELECT, UPDATE, DELETE, BEGIN, COMMIT, ROLLBACK, and EXPLAIN SELECT. A doubled single quote represents one quote inside a name. Complete SQL statements must fit on one line.

Expected output:
O'Neil

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Check both outer quotes before slicing the token.
Hint 2: Consume two interior quote characters for each decoded quote.

Experiment: Try a name containing a semicolon and confirm it stays inside one INSERT.
