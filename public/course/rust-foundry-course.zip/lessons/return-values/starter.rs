fn minutes_to_seconds(minutes: u32) -> u32 {
    minutes + 60
}

fn main() {
    let seconds = minutes_to_seconds(3);
    println!("{seconds}");
}
