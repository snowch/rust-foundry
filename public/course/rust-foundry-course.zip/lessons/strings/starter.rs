fn greeting() -> String {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(greeting(), "Ada!");
    println!("{}", greeting());
}
