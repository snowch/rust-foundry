Return two values together

Goal: Create, unpack, and inspect a pair of values.
Before this lesson: Repeat work with a loop

A tuple groups a fixed number of values. (7, 8) is a pair. Its type can be written (u32, u32), so a function can return both numbers together.

let (left, right) = pair; unpacks the pair into two names. You can also read fields by position: pair.0 is the first and pair.1 is the second. Positions start at zero.

println!("{pair:?}"); uses debug formatting, a readable representation useful for inspecting data. The :? inside a placeholder requests this representation. Tuples, arrays, and many standard types already support it.

Expected output:
(7, 8)

Exercise: Return a pair containing value and the next whole number.

Hint 1: Put the two return expressions inside parentheses, separated by a comma.
Hint 2: Return (value, value + 1).

Experiment: Print the two unpacked names with ordinary placeholders.
