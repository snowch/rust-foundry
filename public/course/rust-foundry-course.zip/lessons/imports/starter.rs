use std::cmp::min;

fn main() {
    let smaller = min(7, 9);
    assert_eq!(smaller, 3);
    println!("{smaller}");
}
