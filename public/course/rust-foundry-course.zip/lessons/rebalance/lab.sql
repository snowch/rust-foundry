INSERT INTO people VALUES (1, 'A', 1);
INSERT INTO people VALUES (2, 'B', 2);
INSERT INTO people VALUES (3, 'C', 3);
INSERT INTO people VALUES (4, 'D', 4);
INSERT INTO people VALUES (5, 'E', 5);
.pages
DELETE FROM people WHERE id = 5;
DELETE FROM people WHERE id = 4;
.pages
.check
