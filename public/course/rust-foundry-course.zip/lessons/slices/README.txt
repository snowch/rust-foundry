Borrow a bounded sequence

A slice is a reference to a sequence plus its length. &[u32] lets a function accept an array or part of a vector without taking ownership.

get returns Option rather than panicking at an invalid index. This makes bounds checking explicit, which is essential when reading an untrusted page file.

Expected output:
9

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Ask for the first element without indexing directly.
Hint 2: Copy the referenced integer and use zero for None.

Experiment: Pass &values[2..2] and predict the result.
