Give a row a type

Goal: Construct and read a record with named fields.
Before this lesson: Borrow part of an array; Read the lifetime of a text literal; Build formatted text as a value

A tuple groups values by position. A struct groups them by named fields, making the meaning of each value clearer. Row has id, name, and score fields.

Each field declaration includes its type. A Row construction names each field and supplies its value. The name field owns a String, so it is created with String::from.

row.id reads the named id field, unlike pair.0 for a tuple position. The helper accepts &Row and formats the fields without taking ownership of the row.

There is no derive attribute in this first struct example. Generating trait implementations is a separate later lesson.

Expected output:
1 | Ada | 90

Exercise: In the practice editor’s main.rs, replace the todo! line in label. Keep main and its supplied checks. Choose Run checks.

Hint 1: Use format! to return an owned String.
Hint 2: Read id, name, and score through the shared reference.

Browser experiment: In the worked program’s main.rs, replace println!("{}", label(&row)); with let other = Row { id: 2, name: String::from("Lin"), score: 80 };
    println!("{}", label(&other));. Run again and compare. Compare the three fields in the two output lines. Which fields did the formatting helper read from the new record?
