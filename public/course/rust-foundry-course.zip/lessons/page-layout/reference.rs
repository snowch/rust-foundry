fn page_offset(id: usize, file_len: usize) -> Option<usize> {
    let start = id.checked_mul(256)?;
    let end = start.checked_add(256)?;
    if end <= file_len { Some(start) } else { None }
}

fn main() {
    assert_eq!(page_offset(0, 512), Some(0));
    assert_eq!(page_offset(1, 512), Some(256));
    assert_eq!(page_offset(2, 512), None);
    assert_eq!(page_offset(usize::MAX, 512), None);
    println!("{}", page_offset(1, 512).unwrap());
}
