fn insertion_sort(values: &mut [i32]) {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let mut values = [9, 2, 7, 1, 5];
    insertion_sort(&mut values);
    assert_eq!(values, [1, 2, 5, 7, 9]);
    let mut repeated = [3, -1, 3, 0, -1];
    insertion_sort(&mut repeated);
    assert_eq!(repeated, [-1, -1, 0, 3, 3]);
    insertion_sort(&mut []);
    println!("{:?}", values);
}
