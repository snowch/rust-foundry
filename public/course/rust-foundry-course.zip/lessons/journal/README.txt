Record intent before installing pages

TinyDB writes an RWL2 journal containing a full validated after-image. First it writes a prepared journal, then a committed journal, then installs the RDB2 snapshot, and finally removes the journal. The committed marker is the redo decision.

The .crash command is a deterministic lab interruption, not a real browser power cut. It exits after the selected stage and preserves the virtual files, which the host saves together. Native writes sync files and their parent directory; the browser shim has no physical fsync guarantee.

Expected output:
prepared: discard; committed: redo

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Choose the action based on the journal’s committed marker.
Hint 2: Return redo for true and discard for false.

Experiment: Run the interruption script, then replace it with SELECT * FROM people; and Run again.
