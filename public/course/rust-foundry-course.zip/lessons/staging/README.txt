Stage changes before publishing

Goal: Keep a committed collection unchanged while editing a candidate copy.
Before this lesson: Find your way around the complete source; Validate before you mutate

A transaction groups changes into one publish decision. Committed state is the last accepted version. Staged state is a candidate version that may still be committed or discarded.

TinyDB begins by cloning its current database. The small helper below uses .to_vec() to make an owned copy of a borrowed slice, then changes only that copy.

BEGIN starts the candidate, and reads in the same session see its staged changes. The next lessons show rollback and commit. This bounded design copies state for clarity rather than providing concurrent database sessions.

Each browser Run starts a fresh process. BEGIN and its COMMIT or ROLLBACK must therefore appear in the same script; an open transaction rolls back when that input ends.

Expected output:
committed [1, 2]; staged [1, 2, 3]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Create an owned Vec from the borrowed slice.
Hint 2: Append to the candidate, not the original.

Experiment: Remove COMMIT from the lab, run it, then query again in another Run to see which version survived.
