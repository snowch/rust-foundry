Queues: first in, first out

Goal: Serve queued work in arrival order, including the empty-queue case.
Before this lesson: Stacks: validate nested delimiters; Find names in the standard library

A queue removes the oldest pending item. VecDeque is a growable ring buffer from std::collections; a use declaration brings its name into scope.

push_back adds a value at the arrival end. pop_front removes the oldest value and returns Option: Some(value) when work exists, None when empty. Reversing those ends changes the order.

The buffer can wrap around its allocation, so removing the front does not shift every remaining item as Vec::remove(0) would. Insertion and removal at its ends take amortized O(1) time; occasional growth can allocate and copy.

Queue storage is O(n) for n pending items. The driver interleaves new arrivals and departures to test more than one initial batch.

Expected output:
10 20 30

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: The helper needs one VecDeque operation.
Hint 2: Return queue.pop_front() directly.

Experiment: Add several arrivals between two departures and predict the complete departure sequence.
