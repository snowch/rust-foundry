Build formatted text as a value

Goal: Use format! to create a String without printing it.
Before this lesson: Own a piece of editable text

println! displays a message. format! uses the same placeholders but returns an owned String instead of displaying anything. That lets another function use the finished text.

The ! on these names marks a macro, a supplied operation that expands into Rust code before compilation. You can use these standard macros without writing a macro definition.

Named placeholders such as {score} use the binding of that name. An empty {} uses the value following the comma, such as format!("score {}", score). Use one supplied value for each empty placeholder.

Expected output:
score 90

Exercise: Return a formatted String containing score followed by the supplied number.

Hint 1: Use format! rather than println! inside the helper.
Hint 2: format!("score {score}") is the returned expression.

Experiment: Build a label with two values and two placeholders.
