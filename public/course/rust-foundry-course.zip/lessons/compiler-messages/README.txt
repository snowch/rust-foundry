Read a compiler message

Goal: Locate and repair a spelling error without rewriting the program.
Before this lesson: Say what kind of number you mean

Before running, the compiler checks whether your source follows Rust’s rules. If it finds a problem, this lesson shows Compiler messages below the same code. A compile error prevents execution; it is feedback about the source, not damage to your device.

A message usually names a problem and a position in main.rs, your source file. Read the first error, find the named instruction, and compare it with the working example.

Rust is case-sensitive: println! and printLn! are different spellings. The compiler may call println! a macro. Here that means the supplied print command; you do not need to write a macro yourself.

Text after // is a comment for the reader. Rust does not execute it. Use comments to explain a change without adding output.

Expected output:
Fixed

Exercise: Run the starter once to read the compile error. Correct only the spelling of the print command, then run again.

Hint 1: Rust command names must match exactly, including letter case.
Hint 2: The correct spelling is println!, all lowercase.

Experiment: Add a comment of your own. Confirm that it does not appear in output.
