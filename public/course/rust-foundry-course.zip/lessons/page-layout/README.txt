Address fixed-size pages

RDB2 divides the file into 256-byte pages. Page 0 is a header; other pages are leaves, branches, or reusable free space. Page IDs become byte offsets by multiplication.

A leaf holds at most four 40-byte rows. Small capacities are intentional: a few inserts reveal splits that would be hard to observe with production-sized pages. This teaching database loads bounded pages into memory and rewrites a snapshot at commit; it is not a disk buffer manager.

Expected output:
256

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Compute both start and end with checked arithmetic.
Hint 2: Only return start when the whole page fits.

Experiment: Run .pages before and after the fifth inserted row; compare the root and leaf pages.
