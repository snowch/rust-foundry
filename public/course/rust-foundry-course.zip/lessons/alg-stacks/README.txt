Stacks: validate nested delimiters

Goal: Use last-in, first-out order to detect mismatched or unfinished brackets.
Before this lesson: Linked lists and owned links; Represent alternatives; Distinguish bytes from letters

A stack removes the most recently added item. Vec::push appends at the top, and pop removes that last item, returning None when the stack is empty.

For nested delimiters, every opening bracket waits for a matching closing bracket. The next close must match the most recent unmatched opening, not any earlier opening.

Iterate text.chars() to read Unicode scalar values. match classifies opening brackets, closing brackets, and ignored text. For a closing bracket, pop and compare its expected opening; finally use is_empty to reject leftover openings.

Each character is visited once, so time is O(n). Up to n openings can be pending, so worst-case auxiliary space is O(n). Equal counts alone cannot detect crossed brackets such as ([)].

Expected output:
true

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Push openings; use match to translate each closing symbol into its expected opening.
Hint 2: Reject when stack.pop() differs from Some(opening), then require stack.is_empty() at the end.

Experiment: Add more text around balanced brackets and verify that non-bracket characters are ignored.
