fn minutes_to_seconds(minutes: u32) -> u32 {
    todo!("Implement functions")
}

fn main() {
    assert_eq!(minutes_to_seconds(0), 0);
    assert_eq!(minutes_to_seconds(2), 120);
    println!("{}", minutes_to_seconds(3));
}
