Rollback discards the candidate

Goal: Discard an entire staged candidate while keeping committed data.
Before this lesson: Stage changes before publishing; Represent a missing value

ROLLBACK abandons all staged changes in this transaction. It does not delete rows that were committed before BEGIN.

Option<Vec<u32>> makes this state explicit: Some(candidate) means a transaction has a staged vector, and None means no active candidate. Assigning None drops that owned candidate.

.is_none() is a boolean check for the None variant. The test verifies both that staged state disappears and that the committed vector remains unchanged.

TinyDB leaves a transaction active after a statement error, preserving the previous staged state. The learner then chooses whether to inspect, commit, or roll back.

Expected output:
[1]; staged: None

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Replace the Option itself, through the mutable reference.
Hint 2: Assign None to *staged.

Experiment: Stage both an update and an insert, roll back, and compare all rows with the pre-BEGIN data.
