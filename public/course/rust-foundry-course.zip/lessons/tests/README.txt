Test an invariant, not one example

Goal: Check codec boundaries and distinguish a round-trip test from an independent fixture.
Before this lesson: Reject short input safely; Ask a sequence for its next item

A round trip encodes a value and decodes the result. The original and decoded values should agree. A boundary is a case where representation changes, such as 255 to 256.

The .all(closure) iterator method returns true only if every supplied value satisfies the comparison. An empty iterator also returns true because no item violates the rule.

A round-trip test can miss two functions sharing the same mistake. Compare known expected bytes too, or exchange a file with an independent implementation.

The assertions here run in main in the browser. A native rustc --test build is a separate way to run Rust test functions; you do not need that command to complete this browser lesson.

Expected output:
round trips pass

Exercise: In the practice editor’s main.rs, replace the todo! line in round_trip. Keep main and its supplied checks. Choose Run checks.

Hint 1: Visit every input using iter().all(...).
Hint 2: Compare from_le_bytes(value.to_le_bytes()) with the original value.

Browser experiment: In the worked program’s main.rs, replace println!("round trips pass"); with assert!(round_trip(&[258]));
    println!("{:?}", 258_u32.to_le_bytes());. Run again and compare. Read the four bytes and compare them with the number. What does inspecting exact bytes tell you in addition to a round trip?
