Give values names

Goal: Store a value with let and display it by name.
Before this lesson: Run instructions in order

A value is a piece of data, such as text or a number. let gives a value a name. In let message = "Hello, Rust!";, message is the name and the quoted greeting is its value.

The = sign here means “bind this name to this value”. The semicolon ends the instruction, just as it ends a print instruction.

To display the value, write println!("{message}");. The braces inside these quotes are a placeholder: Rust replaces {message} with the value named message. These are different from the outer braces that enclose main.

An equivalent spelling is println!("{}", message);. An empty placeholder takes the value supplied after the comma. Later examples use this form to display a calculation or function result directly.

This program needs only main, let, and println!. Functions that return values and borrowed text types come in later lessons.

Expected output:
Hello, Rust!

Exercise: Change the value assigned to message so the program displays Hello, Rust! Use the existing placeholder to print it.

Hint 1: The print instruction is already correct. Edit the greeting on the let line.
Hint 2: Use let message = "Hello, Rust!";.

Experiment: Rename message to greeting in both places. What happens if you rename it in only one place?
