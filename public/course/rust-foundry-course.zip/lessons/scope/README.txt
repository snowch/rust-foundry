Notice where a name is usable

Goal: Identify the block that owns a local value.
Before this lesson: Clone deliberately

A scope is the region where a name can be used. A binding declared inside a block normally remains usable until that block’s closing brace.

When an owned value’s scope ends, Rust drops it: it releases the resources the value owns. You do not manually free a String.

An inner block can declare a new binding with the same spelling as an outer one. This is shadowing: the inner name temporarily hides the outer name, but it does not change the outer value.

Expected output:
inner
outer

Exercise: Change only the inner String to inner. Keep the two scopes and the outer value.

Hint 1: Find the String::from call inside the nested braces.
Hint 2: Replace replace me with inner; leave outer unchanged.

Browser experiment: In the worked program’s main.rs, replace let name = String::from("inner"); with let name = String::from("inside");. Run again and compare. Compare the two lines. Which binding does the print instruction after the braces use?
