fn three_scores() -> Vec<u32> {
    let mut values = vec![10, 20];
    values.push(30);
    values
}

fn main() {
    let values = three_scores();
    assert_eq!(values, [10, 20, 30]);
    assert_eq!(values.len(), 3);
    println!("{values:?}");
}
