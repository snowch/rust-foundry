INSERT INTO people VALUES (1, 'A', 1);
INSERT INTO people VALUES (3, 'C', 3);
INSERT INTO people VALUES (5, 'E', 5);
INSERT INTO people VALUES (7, 'G', 7);
INSERT INTO people VALUES (9, 'I', 9);
EXPLAIN SELECT * FROM people WHERE id = 7;
SELECT * FROM people WHERE id >= 3 AND id <= 7;
.index
