fn text_length(text: &str) -> usize {
    text.len()
}

fn main() {
    let owned = String::from("Ada");
    assert_eq!(text_length("Ada"), 3);
    assert_eq!(text_length(owned.as_str()), 3);
    println!("{}", text_length(owned.as_str()));
}
