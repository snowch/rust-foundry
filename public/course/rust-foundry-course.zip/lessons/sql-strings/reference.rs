fn decode_quoted(token: &str) -> Result<String, &'static str> {
    if !token.starts_with('\'') || !token.ends_with('\'') || token.len() < 2 { return Err("missing quotes"); }
    let mut chars = token[1..token.len()-1].chars();
    let mut result = String::new();
    while let Some(ch) = chars.next() {
        if ch == '\'' && chars.next() != Some('\'') { return Err("unescaped quote"); }
        result.push(ch);
    }
    Ok(result)
}

fn main() {
    assert_eq!(decode_quoted("'O''Neil'").unwrap(), "O'Neil");
    assert!(decode_quoted("'O'Neil'").is_err());
    assert!(decode_quoted("Ada").is_err());
    println!("{}", decode_quoted("'O''Neil'").unwrap());
}
