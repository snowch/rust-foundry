fn child_index(separators: &[u32], key: u32) -> usize {
    separators.partition_point(|separator| *separator <= key)
}

fn main() {
    assert_eq!(child_index(&[10, 20], 9), 0);
    assert_eq!(child_index(&[10, 20], 10), 1);
    assert_eq!(child_index(&[10, 20], 20), 2);
    println!("child {}", child_index(&[10, 20], 15));
}
