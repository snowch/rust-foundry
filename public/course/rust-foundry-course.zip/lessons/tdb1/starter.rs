fn legacy_count(bytes: &[u8]) -> Result<usize, &'static str> {
    todo!("Implement tdb1")
}

fn main() {
    let mut bytes = vec![84, 68, 66, 49, 1, 40, 1, 0];
    bytes.extend([0; 40]);
    assert_eq!(legacy_count(&bytes), Ok(1));
    assert!(legacy_count(&bytes[..47]).is_err());
    println!("{} row header", legacy_count(&bytes).unwrap());
}
