fn name_length(name: &String) -> usize {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let name = String::from("Ada");
    assert_eq!(name_length(&name), 3);
    println!("{} {name}", name_length(&name));
}
