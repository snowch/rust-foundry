Record intent before installing pages

Goal: Choose recovery behaviour based on whether a commit marker exists.
Before this lesson: Commit one new generation; Check whether bytes changed; Write and reopen bytes

A journal records the intended change before replacing committed pages. TinyDB’s RWL2 journal contains a full after-image: the complete candidate RDB2 snapshot for the next generation.

The ordered steps are: write a prepared journal, write its committed marker, install the main snapshot, then remove the journal. A prepared marker alone does not commit the candidate. A committed marker says recovery should redo the saved after-image.

.crash prepare, .crash commit, and .crash install deliberately interrupt the next commit at those stages. Reopen the database in a second Run to observe the actual recovery decision.

These commands are teaching simulations. Native file syncing asks the operating system to flush writes, while a browser virtual filesystem has no physical fsync guarantee. The webpage saves a snapshot after the simulated exit; an actual tab kill has a different persistence boundary, covered in the final lesson.

Recovery happens automatically when the database file is reopened. The .recover inspection command reports the completed recovery generation; it is not required to trigger replay.

Expected output:
prepared: discard; committed: redo

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Choose the action based on the journal’s committed marker.
Hint 2: Return redo for true and discard for false.

Experiment: Run the prepare interruption, then replace the script with SELECT * FROM people; and run again.
