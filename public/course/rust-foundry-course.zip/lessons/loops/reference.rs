fn sum_to_three() -> u32 {
    let mut total = 0;
    for number in 1..=3 { total += number; }
    total
}

fn main() {
    assert_eq!(sum_to_three(), 6);
    println!("{}", sum_to_three());
}
