fn sum_down(value: u32) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(sum_down(0), 0);
    assert_eq!(sum_down(3), 6);
    println!("{}", sum_down(3));
}
