Use a sequence that can grow

Goal: Create a Vec, append an element, and borrow its elements.
Before this lesson: Validate before you mutate; Borrow part of an array

An array’s length is fixed. A Vec is an owned sequence whose length can change. vec![10, 20] creates a vector containing two elements; Vec<u32> names a vector of u32 values.

A mutable vector can append with push(value). Its len() reports the current number of elements. As with String, the owner is responsible for the storage.

A shared reference to a vector can be read as a slice. This lets the same &[u32] function accept an array view or vector view without taking ownership.

Expected output:
[10, 20, 30]

Exercise: Create a two-element mutable vector, append thirty, and return it.

Hint 1: Start with let mut values = vec![10, 20];.
Hint 2: Call values.push(30); before returning values.

Experiment: Append a fourth value and read the new len().
