Propagate with ?

Goal: Propagate a Result error with ? instead of repeating a match.
Before this lesson: Turn overflow into a result

A fallible helper can pass a failure back to its caller. ? returns early when its Result is Err, or extracts the value when it is Ok.

The worked program includes the previous parsing pattern as a named helper, number. You are reusing that helper; the new operation is ? on each call.

After both parses succeed, checked_add and ok_or handle overflow as in the preceding lesson. No closure or map_err knowledge is needed here.

The ? operator is not a panic catcher. It handles the Result values explicitly returned by these operations.

Expected output:
42

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Call the provided number helper on each input and put ? after each call.
Hint 2: Then return a.checked_add(b).ok_or("overflow").

Experiment: Give the two parse failures distinct messages and test each.
