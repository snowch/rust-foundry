Read and change rows with SQL

Goal: Trace INSERT, SELECT, UPDATE, and DELETE on one row.
Before this lesson: Meet a table, row, and column

INSERT INTO people VALUES (1, 'Ada', 90); adds one row. The values follow the schema’s id, name, score order. SQL text uses single quotes; the final semicolon ends the statement.

SELECT * FROM people; reads all columns from all rows. WHERE id = 1 limits the operation to that ID. SELECT COUNT(*) FROM people; reports how many rows match.

UPDATE people SET score = 95 WHERE id = 1; changes that row’s score. DELETE FROM people WHERE id = 1; removes the row. These four kinds of operation are often called CRUD: create, read, update, delete.

The lab uses the real Rust database. Each standalone write saves a committed change, called autocommit. Later lessons explain transactions that group writes together. SQL runs in the TinyDB workspace; the small Rust exercise below models the same field change.

In the supplied Rust helper, let _ = old; explicitly ignores the previous value. The underscore pattern is the ignore pattern from the enum lesson; here it is used in a let statement. The replacement input is the value that should be returned.

Expected output:
95

Exercise: Return the replacement score. let _ = old; explicitly ignores the old input without a warning; keep that provided line.

Hint 1: The replacement is the new field value.
Hint 2: Keep let _ = old; and return replacement.

Experiment: Pause the lab script before DELETE and inspect the updated row.
