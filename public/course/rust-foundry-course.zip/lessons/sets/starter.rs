use std::collections::HashSet;

fn main() {
    let mut seen = HashSet::new();
    assert!(seen.insert(7));
    assert!(!seen.insert(8));
    assert!(seen.contains(&7));
    println!("{}", seen.len());
}
