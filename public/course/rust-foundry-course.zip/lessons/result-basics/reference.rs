fn positive(id: u32) -> Result<u32, &'static str> {
    if id == 0 { Err("id must be positive") } else { Ok(id) }
}

fn main() {
    assert_eq!(positive(0), Err("id must be positive"));
    assert_eq!(positive(7), Ok(7));
    println!("{}", positive(7).unwrap());
}
