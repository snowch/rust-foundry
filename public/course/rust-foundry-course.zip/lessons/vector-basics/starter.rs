fn three_scores() -> Vec<u32> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let values = three_scores();
    assert_eq!(values, [10, 20, 30]);
    assert_eq!(values.len(), 3);
    println!("{values:?}");
}
