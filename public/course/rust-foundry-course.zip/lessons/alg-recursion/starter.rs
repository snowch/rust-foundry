fn factorial(n: u64) -> u64 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(factorial(0), 1);
    assert_eq!(factorial(1), 1);
    assert_eq!(factorial(5), 120);
    assert_eq!(factorial(20), 2_432_902_008_176_640_000);
    println!("{}", factorial(6));
}
