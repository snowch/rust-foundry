fn second(values: [u32; 3]) -> u32 {
    values[1]
}

fn main() {
    let values = [10, 20, 30];
    assert_eq!(values.len(), 3);
    let answer = second(values);
    assert_eq!(answer, 20);
    println!("{answer}");
}
