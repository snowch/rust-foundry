Small values can Copy

u32 implements Copy. Assigning it duplicates the value, so both bindings remain usable. This is a type property, not a rule based only on how many bytes happen to be stored.

An array of Copy values can also be Copy. String cannot be Copy because blindly duplicating its owning fields would create two owners of one allocation.

Expected output:
7 7

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Assign value to another binding.
Hint 2: Return a tuple containing both bindings.

Experiment: Try a String parameter and observe which line the borrow checker rejects.
