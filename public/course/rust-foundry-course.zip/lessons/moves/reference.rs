fn decorate(mut name: String) -> String {
    name.push_str("!");
    name
}

fn main() {
    let name = String::from("Ada");
    let decorated = decorate(name);
    assert_eq!(decorated, "Ada!");
    println!("{decorated}");
}
