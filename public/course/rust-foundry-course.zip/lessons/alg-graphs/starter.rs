use std::collections::VecDeque;

fn shortest(graph: &[Vec<usize>], start: usize, target: usize) -> i32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let graph = vec![vec![1, 3], vec![0, 2], vec![1], vec![0, 4], vec![3]];
    assert_eq!(shortest(&graph, 0, 4), 2);
    assert_eq!(shortest(&graph, 2, 2), 0);
    assert_eq!(shortest(&[vec![], vec![]], 0, 1), -1);
    let cycle = vec![vec![1, 2], vec![0, 2], vec![0, 1]];
    assert_eq!(shortest(&cycle, 0, 2), 1);
    println!("{}", shortest(&graph, 0, 4));
}
