fn greeting() -> &'static str {
    todo!("Implement bindings")
}

fn main() {
    assert_eq!(greeting(), "Hello, Rust!");
    println!("{}", greeting());
}
