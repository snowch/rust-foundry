fn find_name(rows: &[(u32, String)], wanted: u32) -> Option<&str> {
    todo!("Implement option")
}

fn main() {
    let rows = vec![(1, String::from("Ada")), (2, String::from("Lin"))];
    assert_eq!(find_name(&rows, 99), None);
    assert_eq!(find_name(&rows, 2), Some("Lin"));
    println!("{}", find_name(&rows, 1).unwrap_or("missing"));
}
