fn safe_add(a: u32, b: u32) -> Result<u32, &'static str> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(safe_add(19, 23), Ok(42));
    assert_eq!(safe_add(u32::MAX, 1), Err("overflow"));
    println!("{}", safe_add(19, 23).unwrap());
}
