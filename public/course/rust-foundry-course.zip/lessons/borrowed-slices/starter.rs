fn total(values: &[u32]) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let values = [10, 20, 30];
    assert_eq!(total(&values[1..3]), 50);
    assert_eq!(total(&[]), 0);
    println!("{}", total(&values));
}
