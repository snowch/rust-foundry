Represent alternatives

Goal: Handle each named alternative of an enum with match.
Before this lesson: Write a method for a struct

An enum represents a choice between named alternatives called variants. Command::Count carries no additional data; Command::Lookup(42) carries an ID.

match selects the arm whose pattern matches the current variant. An arm has pattern => expression syntax. In Command::Lookup(id), the pattern binds the carried value to id.

The match must handle every possible variant. A pattern written _ means “anything else”, and an _ payload ignores a value you do not need. Explicit variant arms make it easier to notice a newly added case.

Each arm here returns an owned String, using String::from or format!. These operations are already familiar; the new idea is choosing an arm by the enum’s variant.

Expected output:
lookup 42

Exercise: In the practice editor’s main.rs, replace the todo! line in describe. Keep main and its supplied checks. Choose Run checks.

Hint 1: Match both Command variants explicitly.
Hint 2: Bind the Lookup payload to id in its match pattern.

Browser experiment: In the worked program’s main.rs, replace println!("{}", describe(Command::Lookup(42))); with println!("{}", describe(Command::Count));. Run again and compare. Read the new phrase. Which variant selects that match arm, and does it carry an ID?
