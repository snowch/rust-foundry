Meet a table, row, and column

Goal: Describe the three fields of one stored record before using SQL.
Before this lesson: Check whether bytes changed; Give a row a type

A database stores organised records so a later operation can find or change them. TinyDB has one table named people. A table is a collection of rows; each row describes one person.

The columns are the named fields in every row: id, name, and score. The id identifies one person, name is text, and score is a whole number. A schema is the rule describing these columns and the values they allow.

You already modelled a row with a Rust struct. The program below creates one in memory. TinyDB additionally encodes rows into files, indexes IDs, and controls when changes are saved.

SQL is a text command language for asking a database to read or change rows. No SQL knowledge is assumed: the next lesson explains the commands. For now, .tables and .schema are TinyDB inspection commands, with one command on each line.

In the lab, .tables lists table names, .schema describes their columns and rules, and .check validates the current database structure and reports its row/page counts. These are inspection commands, not SQL statements.

Expected output:
1 | Ada | 90

Exercise: Set this row’s score to ninety. Keep its identity, name, and three-column output.

Hint 1: Find score in the struct construction.
Hint 2: Use score: 90.

Experiment: Open the lab and inspect .schema before trying any SQL.
