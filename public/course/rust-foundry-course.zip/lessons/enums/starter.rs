enum Command { Count, Lookup(u32) }

fn describe(command: Command) -> String {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(describe(Command::Count), "count all rows");
    assert_eq!(describe(Command::Lookup(7)), "lookup 7");
    println!("{}", describe(Command::Lookup(42)));
}
