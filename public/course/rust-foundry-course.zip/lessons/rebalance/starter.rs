fn split_keys(mut keys: Vec<u32>) -> (Vec<u32>, Vec<u32>, u32) {
    todo!("Implement rebalance")
}

fn main() {
    let (left, right, separator) = split_keys(vec![1, 3, 5, 7, 9]);
    assert_eq!(left, [1, 3]);
    assert_eq!(right, [5, 7, 9]);
    assert_eq!(separator, 5);
    println!("{left:?} | {separator} | {right:?}");
}
