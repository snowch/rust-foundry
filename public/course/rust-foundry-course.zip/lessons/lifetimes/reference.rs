fn longer<'a>(a: &'a str, b: &'a str) -> &'a str {
    if a.len() >= b.len() { a } else { b }
}

fn main() {
    let first = String::from("Ada");
    let second = String::from("Grace");
    assert_eq!(longer(&first, &second), "Grace");
    assert_eq!(longer("same", "size"), "same");
    println!("{}", longer(&first, &second));
}
