Ask a true-or-false question

Goal: Create and combine boolean comparisons.
Before this lesson: Calculate before printing

A comparison produces a bool, a value that is either true or false. score >= 50 asks whether score is greater than or equal to fifty.

== compares for equality, != means not equal, > and < mean greater and less than, and >= and <= include equality. A single = assigns a value; it does not compare values.

&& means both conditions must be true. || means at least one must be true. ! reverses a boolean: !true is false. These operators will let later validation functions state several rules.

Expected output:
true true

Exercise: Change the passing comparison to include a score of exactly 50.

Hint 1: The rule says at least fifty, including fifty itself.
Hint 2: Use >= rather than > for passes.

Experiment: Change score to 0, then 101. Predict each range check.
