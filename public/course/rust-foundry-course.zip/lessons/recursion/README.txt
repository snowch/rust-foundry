Repeat a smaller version of a problem

Goal: Trace a recursive function until its base case stops further calls.
Before this lesson: Address fixed-size pages; Return a calculated value

A recursive function calls itself to solve a smaller version of the same problem. sum_down(3) can ask for sum_down(2), then add three to that returned result.

A base case ends the chain of calls. Here zero returns zero without another call. Each nonzero call subtracts one from the next input, so the small examples eventually reach that base case.

The results return back through the waiting calls: zero, then one, then three, then six for an input of three. The tree implementation uses the same idea by following a child until it reaches a leaf.

These examples use small inputs. Very deep recursion needs more call storage, so a missing base case or an unbounded depth can stop a program. TinyDB validates and bounds tree depth.

Expected output:
6

Exercise: Return zero at the base case. Otherwise add value to the recursive answer for value minus one.

Hint 1: Handle value == 0 before subtracting one.
Hint 2: Use value + sum_down(value - 1) only in the nonzero branch.

Experiment: Trace the input four on paper before running it.
