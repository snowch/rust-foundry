fn pair_visits(n: u64) -> u64 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(pair_visits(0), 0);
    assert_eq!(pair_visits(1), 0);
    assert_eq!(pair_visits(4), 6);
    assert_eq!(pair_visits(10), 45);
    println!("{}", pair_visits(8));
}
