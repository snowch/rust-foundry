Repeat work with a loop

Goal: Accumulate values from a small numeric range.
Before this lesson: Check a result with an assertion; Change a value with mut

for number in 1..=3 runs its block once for each whole number from one through three, including both ends. number is a fresh binding for the current value.

A mutable total keeps the running sum. The plain range 0..3 excludes its upper end and visits zero, one, and two. Choose the range whose boundary matches your rule.

while condition { ... } repeats while its condition is true; update the relevant value so it can finish. A loop { ... } repeats without a condition until break exits it. Later examples use these forms when the number of steps is not known in advance.

return value; immediately leaves the current function with that value, even from inside a loop or if block. Without an early return, execution continues after the block.

Expected output:
6

Exercise: Start total at zero, add each number in 1..=3, and return total.

Hint 1: Declare a mutable total before the for loop.
Hint 2: Inside the loop use total += number;, then return total afterward.

Experiment: Change the range to 0..3 and predict the new result before updating the check.
