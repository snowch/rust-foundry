fn score_label(score: u32) -> String {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let label = score_label(90);
    assert_eq!(label, "score 90");
    println!("{label}");
}
