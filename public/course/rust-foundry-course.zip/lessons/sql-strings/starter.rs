fn decode_quoted(token: &str) -> Result<String, &'static str> {
    todo!("Implement sql-strings")
}

fn main() {
    assert_eq!(decode_quoted("'O''Neil'").unwrap(), "O'Neil");
    assert!(decode_quoted("'O'Neil'").is_err());
    assert!(decode_quoted("Ada").is_err());
    println!("{}", decode_quoted("'O''Neil'").unwrap());
}
