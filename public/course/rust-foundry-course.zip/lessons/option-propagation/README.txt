Stop a missing calculation with ?

Goal: Propagate None from a checked calculation in an Option-returning function.
Before this lesson: Write and reopen bytes; Turn overflow into a result; Propagate with ?

You used ? with Result to return early on Err. In a function returning Option, ? returns early on None and extracts the value from Some.

checked_mul and checked_sub are the multiplication and subtraction counterparts of checked_add. Each returns None if the operation cannot produce a value of the chosen type.

This lets page-address calculations reject overflow before using an invalid offset. The return type determines which failure form ? propagates; it does not turn Option into Result by itself.

Expected output:
120

Exercise: Use checked_mul with ? and wrap the successful count in Some.

Hint 1: Start with records.checked_mul(size)?.
Hint 2: Return Some(count) after a successful calculation.

Experiment: Try zero records and predict whether the result is Some(0) or None.
