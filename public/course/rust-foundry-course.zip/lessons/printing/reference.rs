fn main() {
    println!("First");
    println!("Second");
}
