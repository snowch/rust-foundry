fn find_name(rows: &[(u32, String)], wanted: u32) -> Option<&str> {
    rows.iter().find(|row| row.0 == wanted).map(|row| row.1.as_str())
}

fn main() {
    let rows = vec![(1, String::from("Ada")), (2, String::from("Lin"))];
    assert_eq!(find_name(&rows, 99), None);
    assert_eq!(find_name(&rows, 2), Some("Lin"));
    println!("{}", find_name(&rows, 1).unwrap_or("missing"));
}
