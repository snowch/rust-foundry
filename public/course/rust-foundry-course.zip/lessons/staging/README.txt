Stage changes before publishing

A transaction groups changes into one publish decision. TinyDB clones the current database into a staged candidate on BEGIN; reads in that session see the staged rows.

This bounded teaching design favors clarity over throughput: it copies state and writes a full snapshot. It provides no concurrent SQL sessions or MVCC. In the browser, BEGIN and its COMMIT or ROLLBACK must be in the same script because each Run starts a fresh process.

Expected output:
committed [1, 2]; staged [1, 2, 3]

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Create an owned Vec from the borrowed slice.
Hint 2: Append to the candidate, not the original.

Experiment: Remove COMMIT from the lab, run it, then SELECT again in a second Run.
