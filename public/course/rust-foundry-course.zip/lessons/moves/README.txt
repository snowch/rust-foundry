Follow a moved String

String owns a heap allocation. Passing it by value transfers ownership to the receiving function. The original binding cannot be used after that move.

Here decorate consumes the String, mutates the allocation through its own binding, and returns ownership to its caller. Moving does not mean copying all the text.

Expected output:
Ada!

Exercise: replace todo!; keep the supplied assertions.

Hint 1: The parameter is mutable, so push_str can append in place.
Hint 2: Return name after appending an exclamation mark.

Experiment: Add println!("{name}") after the call to inspect E0382, then remove it.
