Clone deliberately

Clone is an explicit request to duplicate a value. Cloning a String allocates independent text storage, unlike moving its ownership or borrowing its contents.

Use a clone when two independently mutable owners are part of the design. Use a reference when another function only needs to read.

Expected output:
Ada / Ada Jr

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Clone original before changing the second value.
Hint 2: Only changed needs to be declared mut.

Experiment: Append to both returned Strings independently.
