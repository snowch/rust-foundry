fn decorate(mut name: String) -> String {
    todo!("Implement moves")
}

fn main() {
    let name = String::from("Ada");
    let decorated = decorate(name);
    assert_eq!(decorated, "Ada!");
    println!("{decorated}");
}
