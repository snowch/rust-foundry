Read a String without taking it

Goal: Pass shared access to a function while the caller keeps ownership.
Before this lesson: Notice where a name is usable

Moving a String gives away its ownership. A reference gives temporary access instead. &name creates a shared reference to the String owned by name.

A parameter of type &String accepts that shared access. The receiving function can read the contents but does not own them and cannot change them through this reference.

After this call, name is still the owner and can be printed again. A shared borrow must not overlap a change that could invalidate what it reads. The owner must also stay alive for every use of the reference.

Expected output:
3 Ada

Exercise: Read the borrowed String’s byte length using len(). Do not clone or consume it.

Hint 1: The parameter is already borrowed; read its contents with a method.
Hint 2: Return name.len().

Experiment: Call name_length twice and verify that the original name remains usable.
