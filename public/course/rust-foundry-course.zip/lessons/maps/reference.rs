use std::collections::HashMap;

fn counts(words: &[&str]) -> HashMap<String, u32> {
    let mut result = HashMap::new();
    for word in words {
        let count = result.entry(String::from(*word)).or_insert(0);
        *count += 1;
    }
    result
}

fn main() {
    let counts = counts(&["rust", "db", "rust"]);
    assert_eq!(counts.get("rust"), Some(&2));
    assert_eq!(counts.get("missing"), None);
    println!("rust: {}", counts["rust"]);
}
