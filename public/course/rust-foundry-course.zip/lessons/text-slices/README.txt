Read a view of text with &str

Goal: Use one borrowed-text parameter with a literal and an owned String.
Before this lesson: Read a String without taking it

&str is a shared reference to a view of UTF-8 text. Unlike &String, it does not require the owner to be a String: the view can also refer to text written directly in the program.

A String’s .as_str() method returns such a borrowed text view. It creates neither another owner nor a copy of the text.

The literal "Ada" can already be passed as &str. A function taking &str is therefore a useful choice when it only needs to read text.

Expected output:
3

Exercise: Return the borrowed text view’s length without allocating another String.

Hint 1: Use the len method on the borrowed view.
Hint 2: Return text.len().

Experiment: Pass a different literal and an owned String with the same contents.
