Change a value with mut

Goal: Update a numeric binding deliberately using let mut.
Before this lesson: Give values names

A whole number is another kind of value. Write let score = 10; without quotes to store the number ten. With quotes, "10" would be text instead.

A binding declared with let normally keeps its original value. To permit changes, add mut: let mut score = 10;. mut is short for mutable, meaning changeable.

After that declaration, score = 15; replaces the stored number. score += 5; is a shorter way to say score = score + 5;. The + sign adds numbers.

Only mark a binding mut when the program needs to change it. The worked program starts at 10 and adds 5 twice.

Expected output:
20

Exercise: Add another score += 5; instruction before printing, so the final value is 20.

Hint 1: You need two additions of five to get from ten to twenty.
Hint 2: Repeat score += 5; before println!.

Experiment: Remove mut, run, and find the compiler message. Restore it afterward.
