Follow a moved String

Goal: Trace ownership through a String parameter and returned value.
Before this lesson: Build formatted text as a value

The previous lessons created and changed owned text. Now follow who owns that String: a String parameter takes ownership when it receives the caller’s value.

In decorate(name), ownership moves from name in main into the function’s parameter. Returning the parameter moves ownership into decorated in the caller. A move does not clone the text.

The parameter uses mut because it appends text with the method you already know. After the call, decorated is usable and the original name binding is no longer usable.

The assertions and output use the new owner. To read the text without transferring ownership, we will introduce references in the next chapter.

Expected output:
Ada!

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: The parameter is mutable, so push_str can append in place.
Hint 2: Return name after appending an exclamation mark.

Experiment: Add println!("{name}") after the call, read the moved-value diagnostic, then remove that line.
