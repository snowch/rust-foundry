Report a recoverable error

Result<T, E> distinguishes success from a failure with context. Parsing a positive identifier must reject both malformed text and the disallowed value zero.

A type check alone is not a domain check: u32 accepts zero, while our database schema does not. Validate before changing state.

Expected output:
42

Exercise: replace todo!; keep the supplied assertions.

Hint 1: First parse the text into u32.
Hint 2: Accept only Ok(id) where id > 0.

Experiment: Add assertions for leading zeros and surrounding whitespace; document the behavior.
