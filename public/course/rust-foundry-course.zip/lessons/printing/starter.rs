fn main() {
    println!("Second");
    println!("First");
}
