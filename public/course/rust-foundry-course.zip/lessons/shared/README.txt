Read through a shared borrow

&str is a borrowed view of UTF-8 text. A function taking &str can read a String without becoming its owner, and can also accept a literal.

String::len counts bytes. For text with non-ASCII characters, byte length and character count differ. This matters when TinyDB reserves a fixed number of bytes for a name.

Expected output:
5 café

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use the slice method that reports byte length.
Hint 2: The function only reads text; no clone or ownership transfer is needed.

Experiment: Compare text.len() with text.chars().count() for a crab emoji.
