Validate before you mutate

A failed operation should leave the original value intact. Validate the replacement name before assigning it into the row.

This small rule scales to transactions: build a valid candidate, then publish it. Rust prevents memory errors, but it does not automatically give your application this state guarantee.

Expected output:
Lin

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Check the byte length before assigning.
Hint 2: Use replacement.to_owned() only after validation succeeds.

Experiment: Extend validation to reject ASCII control characters like a newline.
