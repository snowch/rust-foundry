fn main() {
    let message = "A different greeting";
    println!("{message}");
}
