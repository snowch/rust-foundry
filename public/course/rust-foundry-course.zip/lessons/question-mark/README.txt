Propagate with ?

The ? operator returns early on an Err and unwraps an Ok for the next step. It makes a sequence of fallible operations readable without discarding their failures.

map_err adapts one error type into the type your function promises. Here the caller receives a short domain message instead of an integer parser’s error type.

Expected output:
42

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use map_err and ? after both parse calls.
Hint 2: Use checked_add rather than + to make overflow explicit.

Experiment: Give the two parse failures distinct messages and test each.
