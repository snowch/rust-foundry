struct Node { value: i32, next: Option<Box<Node>> }

fn prepend(head: &mut Option<Box<Node>>, value: i32) {
    todo!("Implement this function using the lesson steps")
}

fn values(head: &Option<Box<Node>>) -> Vec<i32> {
    let mut output = Vec::new();
    let mut cursor = head.as_deref();
    while let Some(node) = cursor {
        output.push(node.value);
        cursor = node.next.as_deref();
    }
    output
}
fn main() {
    let mut head = None;
    assert_eq!(values(&head), []);
    prepend(&mut head, 1); prepend(&mut head, 2); prepend(&mut head, 3);
    assert_eq!(values(&head), [3, 2, 1]);
    println!("{:?}", values(&head));
}
