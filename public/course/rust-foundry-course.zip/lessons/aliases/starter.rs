type DbResult<T> = Result<T, String>;

fn positive(value: u32) -> DbResult<u32> {
    todo!("Return an error for zero and the value otherwise")
}

fn main() {
    assert!(positive(0).is_err());
    assert_eq!(positive(7), Ok(7));
    println!("{}", positive(7).unwrap());
}
