Stacks: validate nested delimiters

Goal: Use last-in, first-out order to detect mismatched or unfinished brackets.
Before this lesson: Linked lists and owned links; Represent alternatives; Distinguish bytes from letters

A stack removes the most recently added item. Vec::push appends at the top, and pop removes that last item, returning None when the stack is empty.

For nested delimiters, every opening bracket waits for a matching closing bracket. The next close must match the most recent unmatched opening, not any earlier opening.

Iterate text.chars() to read Unicode scalar values. match classifies opening brackets, closing brackets, and ignored text. For a closing bracket, pop and compare its expected opening; finally use is_empty to reject leftover openings.

Each character is visited once, so time is O(n). Up to n openings can be pending, so worst-case auxiliary space is O(n). Equal counts alone cannot detect crossed brackets such as ([)].

Expected output:
true

Exercise: In the practice editor’s main.rs, replace the todo! line in balanced. Keep main and its supplied checks. Choose Run checks.

Hint 1: Push openings; use match to translate each closing symbol into its expected opening.
Hint 2: Reject when stack.pop() differs from Some(opening), then require stack.is_empty() at the end.

Browser experiment: In the worked program’s main.rs, replace println!("{}", balanced("{[()]}")); with println!("{}", balanced("{[(])}"));. Run again and compare. Compare the booleans. Which closing bracket failed to match the most recent opening bracket?
