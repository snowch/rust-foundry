Rust Foundry — 13 chapters, 75 lessons and 8 optional TinyDB projects

Start at https://snowch.github.io/rust-foundry/#course/first-program
No programming, Rust, or SQL knowledge is assumed. Each lesson lists its goal and earlier prerequisites. Early exercises change ordinary source and compare output; assertions and TODO markers are used only after their introduction.
Run: rustc --edition 2021 starter.rs -o lesson && ./lesson
TinyDB projects each remove one real function from the complete implementation. They are optional extensions after the relevant core lessons and source primer. The reference includes the native invariant suite. See each project README.

No Cargo dependencies are required. Browser compiler version is experimental and pinned; native tests use stable Rust. Files and source stay local when using the website.
