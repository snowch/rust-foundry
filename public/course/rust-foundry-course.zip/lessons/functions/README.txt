Reuse a group of instructions

Goal: Define a named function and call it twice.
Before this lesson: Choose which instruction runs

You have used main as the program’s starting function. You can define another named function to group instructions you want to reuse.

fn greet() { ... } defines a function named greet. greet(); calls it: execution enters that function, runs its body, then returns to the next instruction in main.

A definition alone does not run its body. The two calls in main produce the two greeting lines. The empty parentheses still mean no input values are supplied.

Expected output:
Hello
Hello

Exercise: Add a second greet(); call inside main. Do not duplicate the function definition.

Hint 1: Keep one definition above main.
Hint 2: Repeat greet(); inside main.

Browser experiment: In the worked program’s main.rs, replace greet();
    greet(); with greet();. Run again and compare. Count the Hello lines. How does that count relate to the number of calls in main?
