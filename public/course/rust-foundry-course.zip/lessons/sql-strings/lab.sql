INSERT INTO people VALUES (1, 'O''Neil; Jr', 75);
UPDATE people SET score = 80, name = 'O''Neil' WHERE id = 1;
SELECT * FROM people WHERE id = 1;
