Parse SQL without splitting names

Goal: Decode a SQL quoted-text token without treating its contents as commands.
Before this lesson: Define the row contract; Ask a sequence for its next item

SQL commands contain keywords, numbers, punctuation, and quoted text. A lexer separates these into tokens; a parser checks that their order follows the supported command rules. This helper decodes just one text token.

SQL doubles a quote inside a quoted name: 'O''Neil' represents O'Neil. This differs from Rust’s backslash escape for a quote in a char literal. The source uses '\'' to write one Rust quote character.

.starts_with and .ends_with check the surrounding quotes before slicing. String::new() creates empty owned text, and .push(character) appends one char.

The chars iterator and while let loop use the operations you already learned. On an interior quote, the helper requires and consumes the second quote of the SQL escape pair. A complete parser must also check all remaining tokens and limits.

Expected output:
O'Neil

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Check both outer quotes before slicing the token.
Hint 2: Consume two interior quote characters for each decoded quote.

Experiment: Use a SQL name containing both a quote and a semicolon; verify that the semicolon stays inside the name.
