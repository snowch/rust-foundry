fn main() {
    let seconds = 3 + 60;
    let whole = 7 / 2;
    let remainder = 7 % 2;
    println!("{seconds}");
    println!("{whole} {remainder}");
}
