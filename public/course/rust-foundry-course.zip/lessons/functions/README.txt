Functions have contracts

A function takes typed inputs and returns a typed output. Here the small conversion function keeps its calculation separate from printing.

A u32 can represent zero through 4,294,967,295. This exercise uses small inputs; later we will make overflow part of the return type.

Expected output:
180

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Multiply the parameter by the number of seconds in a minute.
Hint 2: The return expression is minutes * 60.

Experiment: Add an assertion for 10 minutes without changing the printed result.
