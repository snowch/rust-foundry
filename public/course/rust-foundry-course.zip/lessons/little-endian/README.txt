Encode a number explicitly

Goal: Encode a u32 into four bytes in a specified byte order.
Before this lesson: Give a recurring type a readable name; Describe where a borrow comes from; Distinguish bytes from letters

A file format is an agreed rule for translating values into bytes. A u32 uses four bytes, and byte order specifies which byte comes first.

Little-endian puts the least significant byte first. For 258, that is [2, 1, 0, 0]: two units plus one group of 256. .to_le_bytes() encodes this order, and u32::from_le_bytes(...) decodes it.

A numeric literal beginning 0x is hexadecimal, base sixteen. Digits A through F mean ten through fifteen. 0x12345678 is a compact way to show four distinct byte groups in the known-byte test; you do not need to calculate its decimal value.

The returned [u8; 4] is the fixed-size array type you learned earlier. Do not copy a Rust struct’s raw memory as a format: its internal layout and owning fields do not define portable file bytes.

Expected output:
[2, 1, 0, 0]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Use a standard integer conversion, not an unsafe memory cast.
Hint 2: to_le_bytes returns exactly four bytes.

Experiment: Encode 258 and a value with a zero byte in the middle, then decode those arrays back.
