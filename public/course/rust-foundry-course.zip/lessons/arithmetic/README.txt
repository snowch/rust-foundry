Calculate before printing

Goal: Evaluate simple integer arithmetic and recognise division’s remainder.
Before this lesson: Say what kind of number you mean

An expression produces a value. The expression 3 * 60 multiplies three by sixty. Store its result in a binding or supply it directly to a print placeholder.

For numbers, + adds, - subtracts, and * multiplies. / divides. With whole-number types, division keeps only the whole part: 7 / 2 is 3. The % operator gives the remainder: 7 % 2 is 1.

Parentheses group part of an expression so it is calculated together, such as (2 + 1) * 60. These grouping parentheses are separate from the parentheses used to call println!.

Expected output:
180
3 1

Exercise: Repair the seconds calculation by using multiplication. Keep the division and remainder examples.

Hint 1: Adding minutes to sixty is different from multiplying by sixty.
Hint 2: Use let seconds = 3 * 60;.

Experiment: Try 8 / 2 and 8 % 2. Predict both results first.
