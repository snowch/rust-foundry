fn decode_id(bytes: &[u8]) -> Result<u32, &'static str> {
    todo!("Implement decode")
}

fn main() {
    for length in 0..4 { assert!(decode_id(&[0, 0, 0, 0][..length]).is_err()); }
    assert_eq!(decode_id(&[2, 1, 0, 0]), Ok(258));
    println!("{}", decode_id(&[2, 1, 0, 0]).unwrap());
}
