fn verdict(score: u32) -> &'static str {
    if score >= 50 { "pass" } else { "retry" }
}

fn main() {
    assert_eq!(verdict(49), "retry");
    assert_eq!(verdict(50), "pass");
    println!("{}", verdict(90));
}
