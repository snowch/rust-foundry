Commit one new generation

Goal: Advance one generation for a whole successfully committed transaction.
Before this lesson: Rollback discards the candidate; Turn overflow into a result

COMMIT publishes a valid candidate as the next committed state. A generation is a counter identifying that published database version; it is not a row count.

Two successful changes inside one transaction produce one new generation. A standalone write autocommits through the same commit operation, producing its own increment.

checked_add prevents the counter from wrapping and making a new state look like an old version. The full commit protocol records intent before installing pages; the next chapter explains that journal.

A database generation and a browser workspace revision count different things. The final persistence lesson distinguishes the Rust database commit from saving a browser file snapshot.

Expected output:
generation 42

Exercise: In the practice editor’s main.rs, replace the todo! line in next_generation. Keep main and its supplied checks. Choose Run checks.

Hint 1: Do not use wrapping_add for a persistent generation counter.
Hint 2: Return checked_add(1) directly.

Browser experiment: In the worked program’s main.rs, replace println!("generation {}", next_generation(41).unwrap()); with println!("generation {:?}", next_generation(u64::MAX));. Run again and compare. Read the variant. Can the generation wrap back to zero at the largest representable value?
