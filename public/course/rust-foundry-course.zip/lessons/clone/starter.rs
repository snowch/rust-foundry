fn keep_and_change(original: String) -> (String, String) {
    todo!("Implement clone")
}

fn main() {
    let pair = keep_and_change(String::from("Ada"));
    assert_eq!(pair.0, "Ada");
    assert_eq!(pair.1, "Ada Jr");
    println!("{} / {}", pair.0, pair.1);
}
