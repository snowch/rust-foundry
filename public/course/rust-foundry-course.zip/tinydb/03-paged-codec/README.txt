03-paged-codec

Check header, lengths, checksums, page tags, references, and full tree invariants.

Implement the TODO in the otherwise working database.
Native checks: rustc --edition 2021 --test starter.rs -o tinydb-tests && ./tinydb-tests
Native CLI: rustc --edition 2021 starter.rs -o tinydb && ./tinydb people.rdb
Browser: open this milestone in Rust Foundry, compile it, and install it in the workspace. Browser examples are smoke checks; use the native invariant suite for the full check.
