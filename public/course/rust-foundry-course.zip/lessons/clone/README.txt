Clone deliberately

Goal: Make an explicit independent copy of owned text.
Before this lesson: Small values can Copy

A move transfers ownership. .clone() explicitly creates a separate owned value. For a String, that means independent text storage.

The function clones original into changed, then appends to changed. original keeps its contents, as the checks show.

The tuple returns the two independent owners together. Only changed needs mut, because only that local value is edited.

Expected output:
Ada / Ada Jr

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Clone original before changing the second value.
Hint 2: Only changed needs to be declared mut.

Experiment: Append different text to each returned String and observe that they can change independently.
