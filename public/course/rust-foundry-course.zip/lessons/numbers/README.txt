Say what kind of number you mean

Goal: Read and write explicit integer type annotations.
Before this lesson: Change a value with mut

A type describes what kind of value a name can hold. Rust often infers, or works out, the type. A colon lets you state it: let score: u32 = 90;.

u32 means an unsigned 32-bit whole number. A bit is a storage position that holds 0 or 1; using more bits allows more possible values. Unsigned means zero or positive, never negative. u32 holds values from 0 through 4,294,967,295. You do not need to memorise this limit.

u8 is a smaller whole number from 0 through 255; it will represent small storage units called bytes later. u64 allows larger whole numbers. usize is Rust’s whole-number type for collection lengths and positions. Each name identifies a numeric type, not a variable.

Here all arithmetic uses small u32 values. A value must fit its type: a negative value cannot be stored in u32.

Expected output:
95

Exercise: Keep both type annotations and change bonus so the result is 95.

Hint 1: The needed result is five more than the current score.
Hint 2: Set bonus to 5 and keep : u32.

Experiment: Try let small: u8 = 256; and read the error. Restore the working program.
