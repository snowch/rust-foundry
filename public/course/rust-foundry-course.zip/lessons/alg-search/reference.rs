fn search(values: &[i32], target: i32) -> Option<usize> {
    let (mut lo, mut hi) = (0, values.len());
    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        if values[mid] == target { return Some(mid); }
        if values[mid] < target { lo = mid + 1; } else { hi = mid; }
    }
    None
}

fn main() {
    let values = [2, 5, 8, 12, 16, 23, 38, 56];
    assert_eq!(search(&values, 2), Some(0));
    assert_eq!(search(&values, 56), Some(7));
    assert_eq!(search(&values, 13), None);
    assert_eq!(search(&[], 1), None);
    assert_eq!(search(&[9], 9), Some(0));
    println!("{}", search(&values, 23).unwrap());
}
