fn pair_visits(n: u64) -> u64 {
    let mut visits = 0;
    for i in 0..n {
        for _j in i + 1..n { visits += 1; }
    }
    visits
}

fn main() {
    assert_eq!(pair_visits(0), 0);
    assert_eq!(pair_visits(1), 0);
    assert_eq!(pair_visits(4), 6);
    assert_eq!(pair_visits(10), 45);
    println!("{}", pair_visits(8));
}
