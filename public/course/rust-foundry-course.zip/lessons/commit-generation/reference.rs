fn next_generation(current: u64) -> Option<u64> {
    current.checked_add(1)
}

fn main() {
    assert_eq!(next_generation(0), Some(1));
    assert_eq!(next_generation(41), Some(42));
    assert_eq!(next_generation(u64::MAX), None);
    println!("generation {}", next_generation(41).unwrap());
}
