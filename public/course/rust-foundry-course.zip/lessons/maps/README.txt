Count with a map

HashMap associates keys with values. entry handles the present and absent cases through one interface, and or_insert supplies an initial value.

A hash map does not promise iteration order. Tests and displayed output should not depend on an accidental order observed in one run.

Expected output:
rust: 2

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Create an empty HashMap and loop over the words.
Hint 2: Increment the mutable value returned by entry(...).or_insert(0).

Experiment: Print every count after sorting the keys.
