INSERT INTO people VALUES (1, 'Ada', 90);
BEGIN;
UPDATE people SET score = 99 WHERE id = 1;
INSERT INTO people VALUES (2, 'Lin', 80);
SELECT * FROM people;
ROLLBACK;
SELECT * FROM people;
