Encode a number explicitly

A file format must specify byte order instead of relying on a machine’s memory layout. Little-endian writes the least significant byte first.

to_le_bytes and from_le_bytes state the rule directly. Never serialize a Rust struct by copying its memory: padding, layout, and owned pointers are not a portable format.

Expected output:
[2, 1, 0, 0]

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use a standard integer conversion, not an unsafe memory cast.
Hint 2: to_le_bytes returns exactly four bytes.

Experiment: Encode and decode u32::MAX and a value containing a zero byte in the middle.
