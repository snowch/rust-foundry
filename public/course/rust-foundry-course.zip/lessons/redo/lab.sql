.crash commit
INSERT INTO people VALUES (1, 'Ada', 90);
