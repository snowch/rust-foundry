fn checksum(bytes: &[u8]) -> u32 {
    let mut total: u32 = 0;
    for byte in bytes { total = total.wrapping_add(u32::from(*byte)); }
    total
}

fn main() {
    assert_eq!(checksum(&[1, 2, 3]), 6);
    assert_eq!(checksum(&[1, 2]), checksum(&[2, 1]));
    println!("{}", checksum(&[1, 2, 3]));
}
