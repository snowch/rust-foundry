Name a behavior with a trait

Goal: Define and implement a named method contract for a concrete type.
Before this lesson: Record whether a value was seen; Write a method for a struct

A trait names behaviour that a type promises to provide. trait Identified declares an id method; impl Identified for Person supplies that method for Person.

The method receives &self, just like the struct method you already wrote. The body returns the existing id field.

This first trait example uses the concrete Person type in its helper. It introduces no generic function parameters yet. The next lesson uses a trait bound to make one algorithm accept several types.

You have already seen Copy and Clone behaviour. Traits give such behaviour a name that other code can require.

Expected output:
true

Exercise: In the practice editor’s main.rs, replace the todo! line in same_id. Keep main and its supplied checks. Choose Run checks.

Hint 1: Call the trait method on both borrowed arguments.
Hint 2: Compare the returned integer IDs.

Browser experiment: In the worked program’s main.rs, replace println!("{}", same_id(&Person { id: 1 }, &Person { id: 1 })); with println!("{}", same_id(&Person { id: 1 }, &Person { id: 2 }));. Run again and compare. Read the boolean. Which part of each Person supplies the comparison?
