Choose with an expression

An if expression can produce a value. Both branches must agree on the resulting type.

Handle the boundary deliberately. A score of exactly 50 passes this rule; a comparison using > would reject it.

Expected output:
pass

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use an if expression with two string literal branches.
Hint 2: Include equality in the passing comparison.

Experiment: Change the threshold to 60 and update the boundary assertions together.
