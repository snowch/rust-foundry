struct Person { id: u32, name: String, score: u32 }
fn main() {
    let row = Person { id: 1, name: String::from("Ada"), score: 90 };
    assert_eq!(row.id, 1);
    println!("{} | {} | {}", row.id, row.name, row.score);
}
