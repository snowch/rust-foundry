fn rename(name: &mut String, replacement: &str) -> Result<(), &'static str> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    let mut name = String::from("Ada");
    assert!(rename(&mut name, "").is_err());
    assert_eq!(name, "Ada");
    rename(&mut name, "Lin").unwrap();
    assert_eq!(name, "Lin");
    println!("{name}");
}
