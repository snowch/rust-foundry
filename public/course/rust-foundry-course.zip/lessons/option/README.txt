Missing is a value

Goal: Return an optional borrowed name from a small record search.
Before this lesson: Represent a missing value; Borrow part of an array

A search may find a record or find nothing. Option<&str> expresses those outcomes without making a second owned copy of a name.

The helper loops over a borrowed slice of (id, String) tuples. It compares each id and returns Some(name view) as soon as it finds a match. If the loop ends with no match, it returns None.

The returned view refers to data owned by rows, so it cannot outlive that owner. With one borrowed input collection, Rust can infer this relationship; the later lifetime-annotation lesson makes similar relationships explicit.

main uses an array, which you already know. It deliberately does not introduce a Vec or iterator closure before those topics are taught.

Expected output:
Ada

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Search the iterator for a matching first tuple field.
Hint 2: Map a matching row to its name slice.

Experiment: Ask for a missing ID and use match to print a deliberate not-found message.
