Recursive algorithms and stack cost

Goal: Implement a decreasing recursive step with a terminating base case.
Before this lesson: Big O: time, space, and input cases; Reuse a group of instructions

A recursive function calls itself on a smaller problem. factorial(0) is 1; factorial(n) for positive n is n multiplied by factorial(n−1).

The base case ends the chain of calls. Every recursive step reduces n, so the valid nonnegative inputs eventually reach zero. This example restricts n to 0 through 20 so the result fits u64.

Each call waits for a smaller call before completing its multiplication. There are O(n) calls and O(n) pending stack frames. Rust does not promise tail-call optimization.

Recursion expresses a dependency clearly, but it is not automatically faster or more memory-efficient than iteration. Trees later reuse the same smaller-subproblem structure by descending to children.

Expected output:
720

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Return one for the zero case.
Hint 2: For a positive n, return n * factorial(n - 1).

Experiment: Write an iterative version and compare auxiliary space without assuming a timing advantage.
