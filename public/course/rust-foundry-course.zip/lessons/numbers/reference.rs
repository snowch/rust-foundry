fn main() {
    let score: u32 = 90;
    let bonus: u32 = 5;
    println!("{}", score + bonus);
}
