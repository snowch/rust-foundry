use std::collections::HashMap;

fn counts(words: &[&str]) -> HashMap<String, u32> {
    todo!("Implement maps")
}

fn main() {
    let counts = counts(&["rust", "db", "rust"]);
    assert_eq!(counts.get("rust"), Some(&2));
    assert_eq!(counts.get("missing"), None);
    println!("rust: {}", counts["rust"]);
}
