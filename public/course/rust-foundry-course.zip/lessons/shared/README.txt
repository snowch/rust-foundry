Read through a shared borrow

Goal: Measure a borrowed text view in UTF-8 bytes.
Before this lesson: Distinguish bytes from letters

You have now seen shared references, &str text views, and the difference between UTF-8 bytes and characters. This exercise combines those ideas without adding a new ownership rule.

The helper takes &str, reads its byte length, and returns a usize. In byte_len(&name), Rust can use the borrowed String as a text view; name.as_str() is the explicit alternative you already know.

The call does not take ownership. The caller can therefore display name after measuring it. café occupies five bytes, so the supplied assertion expects five.

Expected output:
5 café

Exercise: In the practice editor’s main.rs, replace the todo! line in byte_len. Keep main and its supplied checks. Choose Run checks.

Hint 1: Use the slice method that reports byte length.
Hint 2: The function only reads text; no clone or ownership transfer is needed.

Browser experiment: In the worked program’s main.rs, replace assert_eq!(byte_len(&name), 5); with assert_eq!(byte_len(&name), 4);. Run again and compare. Read the assertion’s actual and expected byte counts. Why does four displayed letters require five bytes here?
