fn recovery_action(committed: bool) -> &'static str {
    todo!("Implement journal")
}

fn main() {
    assert_eq!(recovery_action(false), "discard");
    assert_eq!(recovery_action(true), "redo");
    println!("prepared: {}; committed: {}", recovery_action(false), recovery_action(true));
}
