Transform without taking ownership

Goal: Filter copied numbers and reduce the remaining values to a sum.
Before this lesson: Ask a sequence for its next item

An iterator pipeline connects small operations. .iter() borrows the scores, and .copied() supplies u32 values instead of references to them.

.filter(predicate) keeps items whose predicate returns true. It temporarily lends each candidate to the predicate, so |score| *score >= 50 reads through a reference even though the iterator supplies copied numbers.

.sum() consumes the retained values and adds them. The helper’s u32 return type tells Rust which sum type is expected.

Operations such as filter are lazy: constructing them does not process the whole sequence. A consuming operation such as sum or collect drives the pipeline.

Expected output:
140 from 3 scores

Exercise: In the practice editor’s main.rs, replace the todo! line in passing_total. Keep main and its supplied checks. Choose Run checks.

Hint 1: Borrow scores with iter and copy each small integer.
Hint 2: Filter on >= 50, then sum.

Browser experiment: In the worked program’s main.rs, replace println!("{} from {} scores", passing_total(&scores), scores.len()); with println!("{} from {} scores", passing_total(&[49, 50, 51]), 3);. Run again and compare. Read the total and the input count. Which values in the new slice contributed to the total?
