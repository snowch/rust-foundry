fn balanced(text: &str) -> bool {
    let mut stack = Vec::new();
    for c in text.chars() {
        let opening = match c {
            '(' | '[' | '{' => { stack.push(c); continue; }
            ')' => '(', ']' => '[', '}' => '{', _ => continue,
        };
        if stack.pop() != Some(opening) { return false; }
    }
    stack.is_empty()
}

fn main() {
    assert!(balanced("([]{})"));
    assert!(balanced("text"));
    assert!(balanced(""));
    assert!(!balanced("([)]"));
    assert!(!balanced("("));
    assert!(!balanced("]"));
    println!("{}", balanced("{[()]}"));
}
