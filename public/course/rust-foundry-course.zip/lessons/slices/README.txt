Borrow a bounded sequence

Goal: Handle an empty slice without indexing past its bounds.
Before this lesson: Missing is a value

Direct values[0] indexing assumes an element exists. .first() instead returns Some(reference) for the first element or None for an empty slice.

The helper matches that Option. Some(value) contains a reference, so *value reads the u32. The None arm supplies zero as the chosen fallback.

This reuses slice borrowing and enum matching. It avoids .copied() and iterator pipelines until their own lessons.

Expected output:
9

Exercise: In the practice editor’s main.rs, replace the todo! line in first_or_zero. Keep main and its supplied checks. Choose Run checks.

Hint 1: Match the Option returned by values.first().
Hint 2: Return *value for Some(value), or zero for None.

Browser experiment: In the worked program’s main.rs, replace println!("{}", first_or_zero(&values)); with println!("{}", first_or_zero(&values[2..2]));. Run again and compare. Compare the printed numbers. Which match arm handles the empty slice?
