Address fixed-size pages

Goal: Calculate a fixed page’s offset while rejecting overflow and truncation.
Before this lesson: Exchange files with C Foundry; Stop a missing calculation with ?

TDB1 stores a simple sequence of records. TinyDB’s normal RDB2 format divides a file into fixed-size pages of 256 bytes, so each page ID can be translated into a byte offset.

Page zero contains the file header. Other pages hold rows, index branches, or reusable free space. The later tree-lookup lesson explains how branches and row-holding leaves form a tree.

Page id starts at id * 256 and ends just before start + 256. Both calculations must be checked for numeric overflow, and the entire page must fit inside the file.

The helper returns Some(start) for a whole valid page and None otherwise. Its ? operators propagate None as in the earlier optional-calculation lesson. TinyDB loads these bounded pages into memory; its commit writes a complete snapshot rather than implementing a disk cache.

The lab command .pages lists actual page IDs, page types, and the keys they hold. Compare its output before and after the insert that exceeds a leaf’s capacity.

Expected output:
256

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Compute both start and end with checked arithmetic.
Hint 2: Only return start when the whole page fits.

Experiment: Compare a 300-byte file with a 512-byte file when requesting page one.
