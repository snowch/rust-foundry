fn main() {
    let text = "cafe";
    println!("{} bytes", text.len());
    for letter in text.chars() {
        println!("{letter}");
    }
}
