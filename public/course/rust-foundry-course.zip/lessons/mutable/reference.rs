fn award(score: &mut u32) {
    *score += 5;
}

fn main() {
    let mut score = 10;
    award(&mut score);
    assert_eq!(score, 15);
    award(&mut score);
    assert_eq!(score, 20);
    println!("{score}");
}
