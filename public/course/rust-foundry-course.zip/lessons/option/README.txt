Missing is a value

Goal: Return an optional borrowed name from a small record search.
Before this lesson: Represent a missing value; Borrow part of an array

A search may find a record or find nothing. Option<&str> expresses those outcomes without making a second owned copy of a name.

The helper loops over a borrowed slice of (id, String) tuples. It compares each id and returns Some(name view) as soon as it finds a match. If the loop ends with no match, it returns None.

The returned view refers to data owned by rows, so it cannot outlive that owner. With one borrowed input collection, Rust can infer this relationship; the later lifetime-annotation lesson makes similar relationships explicit.

main uses an array, which you already know. It deliberately does not introduce a Vec or iterator closure before those topics are taught.

Expected output:
Ada

Exercise: In the practice editor’s main.rs, replace the todo! line in find_name. Keep main and its supplied checks. Choose Run checks.

Hint 1: Search the iterator for a matching first tuple field.
Hint 2: Map a matching row to its name slice.

Browser experiment: In the worked program’s main.rs, replace println!("{}", find_name(&rows, 1).unwrap_or("missing")); with println!("{}", find_name(&rows, 99).unwrap_or("missing"));. Run again and compare. Read the printed text. Why does this lookup use the supplied fallback?
