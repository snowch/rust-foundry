Pass a value into a function

Goal: Call the same function with different u32 inputs.
Before this lesson: Reuse a group of instructions; Say what kind of number you mean

A parameter names an input inside a function. In fn show_score(score: u32), score is the parameter and u32 states which type it accepts.

An argument is the actual value supplied by a call. show_score(90); supplies ninety. The function uses that value wherever its parameter name appears.

Each call gets its own parameter value. The same function can display different scores without changing its definition.

Expected output:
score 90
score 75

Exercise: Change only the second call’s argument so it displays score 75.

Hint 1: Leave the function definition alone.
Hint 2: The second call should be show_score(75);.

Experiment: Add a third call with a different score.
