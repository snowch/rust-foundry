Seek through a B+ tree

Goal: Choose the correct child using a sorted separator list.
Before this lesson: Repeat a smaller version of a problem; Keep sorted, unique rows; Write a small operation as a value

A tree arranges nodes in levels. Search begins at the root. A branch directs the search to a child, while a leaf holds actual rows. A B+ tree keeps every row in sorted leaves, with branches used only for direction.

A separator key is the smallest key in the child to its right. With separators [10, 20], keys below ten go to child zero, ten through nineteen to child one, and twenty or more to child two.

.partition_point(predicate) finds the boundary where a rule stops being true in sorted data. Here it counts separators <= the sought key. The closure syntax and shared-reference dereference are already familiar.

A point lookup follows one root-to-leaf path. A range query seeks its first key and then follows links between leaves. EXPLAIN reports the actual page path; it does not substitute a different search engine.

In the lab, .index describes the index and its height, meaning the number of levels from root to leaf. WHERE id >= 3 AND id <= 7 combines two SQL limits with AND; it selects the inclusive range from three through seven.

Expected output:
child 1

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Count the separators that are <= the requested key.
Hint 2: partition_point finds that boundary in sorted separators.

Experiment: Compare EXPLAIN paths for a present key, a missing key, and a bounded range in the lab.
