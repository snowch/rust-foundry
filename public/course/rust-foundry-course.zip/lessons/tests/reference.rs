fn round_trip(values: &[u32]) -> bool {
    values.iter().all(|value| u32::from_le_bytes(value.to_le_bytes()) == *value)
}

fn main() {
    assert!(round_trip(&[]));
    assert!(round_trip(&[0, 1, 255, 256, 65535, u32::MAX]));
    println!("round trips pass");
}
