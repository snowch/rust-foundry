fn valid_name(name: &str) -> bool {
    !name.is_empty() && name.len() <= 31 && !name.bytes().any(|b| b < 32 || b == 127)
}

fn main() {
    assert!(valid_name("café"));
    assert!(!valid_name(""));
    assert!(!valid_name("Ada\n"));
    assert!(!valid_name(&"é".repeat(16)));
    println!("name validation passes");
}
