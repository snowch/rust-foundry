fn sum_down(value: u32) -> u32 {
    if value == 0 { 0 } else { value + sum_down(value - 1) }
}

fn main() {
    assert_eq!(sum_down(0), 0);
    assert_eq!(sum_down(3), 6);
    println!("{}", sum_down(3));
}
