BEGIN;
INSERT INTO people VALUES (1, 'Ada', 90);
INSERT INTO people VALUES (2, 'Lin', 80);
COMMIT;
.pages
.check
