Commit one new generation

Goal: Advance one generation for a whole successfully committed transaction.
Before this lesson: Rollback discards the candidate; Turn overflow into a result

COMMIT publishes a valid candidate as the next committed state. A generation is a counter identifying that published database version; it is not a row count.

Two successful changes inside one transaction produce one new generation. A standalone write autocommits through the same commit operation, producing its own increment.

checked_add prevents the counter from wrapping and making a new state look like an old version. The full commit protocol records intent before installing pages; the next chapter explains that journal.

A database generation and a browser workspace revision count different things. The final persistence lesson distinguishes the Rust database commit from saving a browser file snapshot.

Expected output:
generation 42

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Do not use wrapping_add for a persistent generation counter.
Hint 2: Return checked_add(1) directly.

Experiment: Compare .pages generation changes for two standalone inserts and two inserts in one explicit transaction.
