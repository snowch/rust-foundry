fn double(value: u32) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(double(0), 0);
    assert_eq!(double(3), 6);
    println!("checks passed");
}
