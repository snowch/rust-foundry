Split, merge, and preserve invariants

Goal: Split an overflowing sorted leaf without losing its promoted key.
Before this lesson: Seek through a B+ tree; Use a sequence that can grow

TinyDB deliberately uses small capacities: four rows per leaf and five child pointers per branch. Occupancy means how many entries a node currently holds. These small limits let a short lab reveal structural changes.

The helper is called on a known, nonempty overflow vector. For five sorted keys, split_off(len / 2) leaves two on the left and returns three on the right. The first right key becomes the parent separator, but remains a data key in the right leaf.

In the full tree, the new right leaf is linked into the leaf chain and inserted into its parent. An overflowing parent splits too; a split root creates a new level.

Deletion needs the opposite repair: borrow an entry from a sibling with spare capacity, or merge two small nodes and free the removed page. A one-child root collapses. These are the full implementation’s invariants; .check validates them after the lab operations.

Expected output:
[1, 3] | 5 | [5, 7, 9]

Exercise: In the practice editor’s main.rs, replace the todo! line in split_keys. Keep main and its supplied checks. Choose Run checks.

Hint 1: Use split_off at the middle index.
Hint 2: The separator is right[0]; do not remove it.

Browser experiment: In the worked program’s main.rs, replace println!("{left:?} | {separator} | {right:?}"); with let (left, right, separator) = split_keys(vec![2, 4, 6, 8, 10]);
    println!("{left:?} | {separator} | {right:?}");. Run again and compare. Compare the left list, separator, and right list. Where does the separator also remain as a key?
