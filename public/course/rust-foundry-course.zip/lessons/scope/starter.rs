fn main() {
    let name = String::from("outer");
    {
        let name = String::from("replace me");
        println!("{name}");
    }
    println!("{name}");
}
