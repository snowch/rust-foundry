Borrow part of an array

Goal: Pass a checked, known-valid array range as a borrowed slice.
Before this lesson: Store a fixed-size sequence; Change through one mutable borrow

A slice is a borrowed view of a sequence, with a known length. &[u32] means shared access to a sequence of u32 values; it does not fix the number of elements in the type.

&values[1..3] borrows the elements at indices one and two. As with a numeric range, .. excludes the upper boundary. The owner must remain alive while the slice is used.

A for loop over a shared slice gives a shared reference to each value. *value reads the referenced integer. This is dereferencing, the same operation you used with a mutable reference.

Expected output:
60

Exercise: Add each referenced integer to a mutable total, then return that total. An empty slice should return zero.

Hint 1: Start a mutable result at zero.
Hint 2: Use result += *value inside the loop, then return result.

Experiment: Pass &values[0..0] and predict the total.
