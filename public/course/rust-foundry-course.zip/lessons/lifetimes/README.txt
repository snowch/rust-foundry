Describe where a borrow comes from

A lifetime annotation describes a relationship between references. It does not extend how long data exists or allocate a longer-lived copy.

This function may return either input. Its return value is valid for a lifetime supported by both input borrows.

Expected output:
Grace

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Compare byte lengths without moving either input.
Hint 2: Return a on ties and b only when it is longer.

Experiment: Try returning a slice of a local String and inspect E0515.
