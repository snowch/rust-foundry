#[derive(Debug)]
struct Row { id: u32, name: String, score: u32 }

fn label(row: &Row) -> String {
    format!("{} | {} | {}", row.id, row.name, row.score)
}

fn main() {
    let row = Row { id: 1, name: "Ada".into(), score: 90 };
    assert_eq!(label(&row), "1 | Ada | 90");
    println!("{}", label(&row));
}
