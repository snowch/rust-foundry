fn decode_id(bytes: &[u8]) -> Result<u32, &'static str> {
    let first = bytes.get(..4).ok_or("short input")?;
    let array: [u8; 4] = first.try_into().map_err(|_| "short input")?;
    Ok(u32::from_le_bytes(array))
}

fn main() {
    for length in 0..4 { assert!(decode_id(&[0, 0, 0, 0][..length]).is_err()); }
    assert_eq!(decode_id(&[2, 1, 0, 0]), Ok(258));
    println!("{}", decode_id(&[2, 1, 0, 0]).unwrap());
}
