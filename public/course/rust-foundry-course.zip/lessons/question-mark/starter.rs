fn add_text(a: &str, b: &str) -> Result<u32, &'static str> {
    todo!("Implement question-mark")
}

fn main() {
    assert_eq!(add_text("x", "2"), Err("bad number"));
    assert_eq!(add_text("4294967295", "1"), Err("overflow"));
    assert_eq!(add_text("19", "23"), Ok(42));
    println!("{}", add_text("19", "23").unwrap());
}
