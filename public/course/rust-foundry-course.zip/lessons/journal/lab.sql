.crash prepare
INSERT INTO people VALUES (1, 'Ada', 90);
