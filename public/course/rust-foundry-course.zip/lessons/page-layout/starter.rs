fn page_offset(id: usize, file_len: usize) -> Option<usize> {
    todo!("Implement page-layout")
}

fn main() {
    assert_eq!(page_offset(0, 512), Some(0));
    assert_eq!(page_offset(1, 512), Some(256));
    assert_eq!(page_offset(2, 512), None);
    assert_eq!(page_offset(usize::MAX, 512), None);
    println!("{}", page_offset(1, 512).unwrap());
}
