04-index-insertion

Insert recursively; split leaves and branches; return a separator and new right page on overflow.

Implement the TODO in the otherwise working database.
Native checks: open a terminal in this project folder. Run rustc --edition 2021 --test starter.rs -o tinydb-tests && ./tinydb-tests. Read the test names and assertion messages. An unfinished todo! reports a panic when its function is called.
Native CLI: rustc --edition 2021 starter.rs -o tinydb && ./tinydb people.rdb
Browser: in TinyDB workspace, open Optional Rust source and project starters. Choose the matching project and Open project starter in editor. Locate the same todo! line. Choose Run code, inspect output, then choose Use compiled TinyDB in workspace. Use a new database filename for tests. The native tests exercise more inputs and failure paths than the supplied browser scripts.
