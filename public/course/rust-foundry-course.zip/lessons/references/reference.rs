fn name_length(name: &String) -> usize {
    name.len()
}

fn main() {
    let name = String::from("Ada");
    assert_eq!(name_length(&name), 3);
    println!("{} {name}", name_length(&name));
}
