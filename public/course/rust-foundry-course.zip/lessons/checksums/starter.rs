fn checksum(bytes: &[u8]) -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(checksum(&[1, 2, 3]), 6);
    assert_eq!(checksum(&[1, 2]), checksum(&[2, 1]));
    println!("{}", checksum(&[1, 2, 3]));
}
