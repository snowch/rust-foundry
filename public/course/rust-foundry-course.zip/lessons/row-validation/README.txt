Define the row contract

TinyDB has one people table: a positive unique u32 id, a UTF-8 name occupying 1–31 bytes with no ASCII control characters, and a u32 score. A small, fixed schema keeps storage work visible.

Validate a row before inserting it. The database also checks uniqueness; the name validator cannot establish that on its own. Run the SQL lab to use the real Rust database, then inspect its complete source.

Expected output:
name validation passes

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use name.len() for UTF-8 byte length.
Hint 2: Reject bytes below 32 and the DEL byte 127.

Experiment: Insert a duplicate id in the lab and verify that the original row remains.
