fn redo_decision(current: u64, base: u64, target: u64, identical: bool) -> Result<&'static str, &'static str> {
    if base.checked_add(1) != Some(target) { return Err("bad generation"); }
    if current == base { Ok("install") }
    else if current == target && identical { Ok("already installed") }
    else { Err("conflict") }
}

fn main() {
    assert_eq!(redo_decision(4, 4, 5, false), Ok("install"));
    assert_eq!(redo_decision(5, 4, 5, true), Ok("already installed"));
    assert!(redo_decision(5, 4, 5, false).is_err());
    assert!(redo_decision(8, 4, 5, true).is_err());
    println!("{}", redo_decision(5, 4, 5, true).unwrap());
}
