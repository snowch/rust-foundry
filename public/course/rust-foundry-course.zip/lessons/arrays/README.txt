Store a fixed-size sequence

Goal: Read an array by its zero-based position.
Before this lesson: Return two values together

An array stores several values of the same type in a fixed order. [10, 20, 30] is an array of three integers. Square brackets distinguish an array from a tuple.

An index is an element’s position. values[0] reads the first element and values[1] reads the second. values.len() gives the number of elements; .len() is a method, a named operation called on a value with a dot.

The type [u32; 3] means three u32 elements. [0; 4] is also a value expression: create four zeroes. A position equal to the length is already outside the array. An invalid index stops the program; later we will learn checked access.

Expected output:
20

Exercise: Return the second element, using its zero-based index.

Hint 1: Count positions starting at zero.
Hint 2: Use values[1].

Experiment: Print the complete array with {:?} and compare it with the tuple representation.
