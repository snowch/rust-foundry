fn parse_id(text: &str) -> Result<u32, &'static str> {
    todo!("Implement result")
}

fn main() {
    assert!(parse_id("0").is_err());
    assert!(parse_id("-1").is_err());
    assert!(parse_id("4294967296").is_err());
    assert_eq!(parse_id("42"), Ok(42));
    println!("{}", parse_id("42").unwrap());
}
