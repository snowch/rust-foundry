Write and reopen bytes

Goal: Save a byte sequence and read the same bytes back from a file.
Before this lesson: Test an invariant, not one example; Give a recurring type a readable name; Find names in the standard library

A file is a named sequence of bytes. A filesystem keeps track of those names and contents. A database file is still bytes; a file format gives those bytes a meaning.

std::fs::write(name, bytes) writes the supplied bytes. std::fs::read(name) returns them as Vec<u8>. Both operations return Result because file access can fail.

Here main returns std::io::Result<()>, a standard type alias for a result with an input/output error. ? propagates a file failure, and Ok(()) reports successful completion. This is the same Result pattern you already learned, with the library’s error type.

Ordinary lesson runs have a temporary filesystem: the file exists only for this run. The TinyDB workspace later saves complete file snapshots between runs. Do not infer that any editor write is automatically saved on your phone.

Expected output:
3 bytes reopened

Exercise: Read back the same filename that was written. Keep the byte equality check.

Hint 1: Compare the quoted filename in write with the one in read.
Hint 2: Read sample.bin rather than missing.bin.

Experiment: Change one byte and predict the reopened contents without changing the filename.
