fn positive(id: u32) -> Result<u32, &'static str> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(positive(0), Err("id must be positive"));
    assert_eq!(positive(7), Ok(7));
    println!("{}", positive(7).unwrap());
}
