fn byte_count(records: usize, size: usize) -> Option<usize> {
    let count = records.checked_mul(size)?;
    Some(count)
}

fn main() {
    assert_eq!(byte_count(3, 40), Some(120));
    assert_eq!(byte_count(usize::MAX, 40), None);
    println!("{}", byte_count(3, 40).unwrap());
}
