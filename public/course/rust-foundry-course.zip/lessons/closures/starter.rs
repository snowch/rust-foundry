fn main() {
    let bonus = 5;
    let add_bonus = |value: u32| value;
    assert_eq!(add_bonus(10), 15);
    println!("{}", add_bonus(10));
}
