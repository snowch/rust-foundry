Binary search trees and height

Goal: Insert unique keys into an owned binary search tree and traverse them in order.
Before this lesson: Linked lists and owned links; Recursive algorithms and stack cost; Implement binary search

A binary search tree keeps smaller keys in the left subtree and larger keys in the right. Each child is an Option<Box<Node>>, reusing the owned-link representation from linked lists.

Insert descends to the appropriate child until an empty link becomes a new leaf. This set ignores equal keys. A mutable match lends access to the child being updated without taking away the whole tree.

An in-order traversal visits left subtree, current key, then right subtree, so the values appear in sorted order. It borrows the tree and uses push to append values to an output Vec.

Insertion takes O(h), where h is height. A balanced tree has logarithmic height, but this unbalanced implementation can become a chain with O(n) height. Nodes use O(n) storage; traversal adds O(h) call-stack space, plus its output. TinyDB’s later B+ tree uses wider balanced nodes instead.

Expected output:
[1, 2, 3, 5, 7]

Exercise: Replace the todo! marker in the named function. Keep the supplied main and all assertions.

Hint 1: Match on the current link, recurse left or right based on key comparison, and ignore equality.
Hint 2: At None, assign a Box::new(Node { key, left: None, right: None }).

Experiment: Insert ascending keys, draw the resulting shape, and compare its height with a balanced arrangement.
