fn compare_revision(expected: u64, current: u64) -> Result<u64, &'static str> {
    todo!("Implement browser-storage")
}

fn main() {
    assert_eq!(compare_revision(3, 3), Ok(4));
    assert_eq!(compare_revision(3, 4), Err("stale workspace"));
    assert!(compare_revision(u64::MAX, u64::MAX).is_err());
    println!("{}", compare_revision(3, 3).unwrap());
}
