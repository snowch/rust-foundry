fn value_or_zero(value: Option<u32>) -> u32 {
    match value { Some(number) => number, None => 0 }
}

fn main() {
    assert_eq!(value_or_zero(None), 0);
    assert_eq!(value_or_zero(Some(7)), 7);
    println!("{}", value_or_zero(Some(7)));
}
