fn score_label(score: u32) -> String {
    format!("score {score}")
}

fn main() {
    let label = score_label(90);
    assert_eq!(label, "score 90");
    println!("{label}");
}
