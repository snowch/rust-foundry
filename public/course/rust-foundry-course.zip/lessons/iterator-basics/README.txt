Ask a sequence for its next item

Goal: Read iterator items until next returns None.
Before this lesson: Write a small operation as a value; Represent a missing value; Distinguish bytes from letters

An iterator is a value that supplies items one at a time. .iter() borrows the elements of a collection. Its .next() returns Some(item) until there are no items left, then returns None.

while let Some(item) = iterator.next() repeats only while the result matches Some. It binds the item for that repetition and stops on None. This combines a while loop with the enum patterns you learned.

An iterator from .iter() yields references. .copied() can turn borrowed Copy values, such as &u32, into u32 values. .collect() gathers items into a collection; a type such as let values: Vec<u32> tells Rust what to build.

A predicate is an operation returning bool, often written as a closure. Iterator methods .any(predicate) and .all(predicate) test whether any or every item satisfies the rule. A later pipeline lesson combines filtering with a sum.

Expected output:
6

Exercise: Create an iterator, repeatedly read its next item, and add each dereferenced integer.

Hint 1: Use let mut items = values.iter(); and a mutable total.
Hint 2: while let Some(value) = items.next() lets you add *value until the sequence ends.

Experiment: Use values.iter().copied().collect() with a Vec<u32> type annotation.
