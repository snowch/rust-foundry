fn sum_to_three() -> u32 {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert_eq!(sum_to_three(), 6);
    println!("{}", sum_to_three());
}
