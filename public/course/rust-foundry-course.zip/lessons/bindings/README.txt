Give values names

A binding gives a value a name. Rust infers many types, but a function boundary makes the contract explicit: greeting returns a string slice that lives for the whole program.

String literals are already stored in the program. Returning one does not allocate a String. println! formats a value and adds a newline.

Expected output:
Hello, Rust!

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Return the exact string literal requested by the assertion.
Hint 2: Leave the final expression without a semicolon.

Experiment: Add the semicolon, read the compiler message, then remove it.
