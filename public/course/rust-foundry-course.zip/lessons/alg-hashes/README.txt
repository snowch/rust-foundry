Hashing, collisions, and deterministic output

Goal: Count repeated words with a hash map and sort only for display.
Before this lesson: Big O: time, space, and input cases; Count with a map; Transform without taking ownership

A hash map uses a key’s hash to choose where to search. Different keys can lead to the same destination: a collision. Correct lookup also compares keys, because a hash is not a unique identifier.

HashMap insertion and lookup take expected O(1) time under normal hashing assumptions. This is not a guaranteed worst-case bound, and it does not include unbounded work for hashing an arbitrarily long string.

split_whitespace visits words. entry(word).or_insert(0) gets a mutable count, creating zero when absent. Dereference and increment it for every occurrence. The map borrows word slices from text, which remains alive for the function call.

Map iteration order is unspecified. Collect keys into a Vec and sort_unstable them before printing counts. That display sort costs O(k log k) for k distinct keys; it is separate from counting.

Expected output:
apple 1
pear 2

Exercise: In the practice editor’s main.rs, replace the todo! line in counts. Keep main and its supplied checks. Choose Run checks.

Hint 1: Create a map and iterate over text.split_whitespace().
Hint 2: Increment *result.entry(word).or_insert(0) and return the map.

Browser experiment: In the worked program’s main.rs, replace let result = counts("pear apple pear"); with let result = counts("pear apple pear Pear");. Run again and compare. Compare the output lines. Is Pear counted as the same key as pear?
