fn greeting() -> &'static str {
    let message = "Hello, Rust!";
    message
}

fn main() {
    assert_eq!(greeting(), "Hello, Rust!");
    println!("{}", greeting());
}
