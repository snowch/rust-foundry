fn keep_and_change(original: String) -> (String, String) {
    let mut changed = original.clone();
    changed.push_str(" Jr");
    (original, changed)
}

fn main() {
    let pair = keep_and_change(String::from("Ada"));
    assert_eq!(pair.0, "Ada");
    assert_eq!(pair.1, "Ada Jr");
    println!("{} / {}", pair.0, pair.1);
}
