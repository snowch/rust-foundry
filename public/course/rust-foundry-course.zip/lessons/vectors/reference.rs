fn insert_key(keys: &mut Vec<u32>, key: u32) -> Result<(), &'static str> {
    match keys.binary_search(&key) {
        Ok(_) => Err("duplicate"),
        Err(index) => { keys.insert(index, key); Ok(()) }
    }
}

fn main() {
    let mut keys = vec![1, 5];
    insert_key(&mut keys, 3).unwrap();
    assert!(insert_key(&mut keys, 3).is_err());
    assert_eq!(keys, [1, 3, 5]);
    println!("{keys:?}");
}
