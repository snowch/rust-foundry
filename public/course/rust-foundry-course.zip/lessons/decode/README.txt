Reject short input safely

Goal: Check input bounds before decoding a fixed-size integer.
Before this lesson: Encode a number explicitly; Propagate with ?; Write a small operation as a value

A decoder cannot assume the file is long enough. bytes.get(..4) asks for the first four bytes and returns Option, instead of panicking on a short input. The ..4 range means zero through the position before four.

.ok_or("short input") converts absence into an error, and ? propagates it as you have already practised.

.try_into() attempts to convert the checked slice into the required [u8; 4] array. It returns Result. .map_err(closure) changes only an Err value, here into our chosen fixed message; the closure’s _ ignores the original conversion error.

Only after those checks does from_le_bytes interpret the four bytes as a number. Invalid input returns an error without indexing beyond the available bytes.

Expected output:
258

Exercise: Replace the todo! marker in the named function. Keep the supplied main and its checks.

Hint 1: Use get(..4) to check the slice bound.
Hint 2: Convert that checked slice into [u8; 4], then decode little-endian.

Experiment: Require exactly four bytes by adding a length check, then test a five-byte input.
