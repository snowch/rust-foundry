fn main() {
    let name = String::from("outer");
    {
        let name = String::from("inner");
        println!("{name}");
    }
    println!("{name}");
}
