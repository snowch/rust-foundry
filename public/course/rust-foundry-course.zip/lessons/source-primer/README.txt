Find your way around the complete source

Goal: Locate the boundary between a TinyDB operation and its supplied helpers.
Before this lesson: Split, merge, and preserve invariants; Give a recurring type a readable name; Write and reopen bytes

The complete TinyDB program is longer than a lesson example. Row validates one record. Database owns the page arena and index operations. Session chooses staged or committed state and saves files. Start from the named operation you are studying, not from the first import in the file.

Private helpers such as node, alloc, and branch are supplied operations. Read their input and output types, then their comments. The eight optional implementation projects remove one operation at a time while keeping the other helpers available. You are not expected to reconstruct the entire program unaided.

Path is a borrowed filesystem path and PathBuf is an owned path, analogous to borrowed text and an owned String. The standard Read, BufRead, and Write traits supply input/output methods. Trait imports make those methods available; these are standard-library APIs, not new SQL rules.

#[cfg(...)] is a conditional-compilation attribute: it includes a section only for a named build target. The reference uses it for native file syncing versus the browser’s virtual filesystem. Those platform-specific helpers are provided scaffold; do not edit them for a tree or parser project.

All later transaction and recovery lessons still use small, complete Rust programs first. The full source and project starters are an optional extension after the relevant lessons, rather than a prerequisite for following the core course.

Some supplied code uses impl FnOnce(...) for a closure called at most once, or collect::<DbResult<Vec<_>>>() to gather successful iterator items while propagating the first error. The underscore asks Rust to infer the element type. These combine the closure, trait-bound, Result, and collection ideas already taught. Named enum-variant fields can be bound or renamed in a match, such as rows: mut target; the pattern borrows or moves the declared fields according to the same ownership rules.

Expected output:
7

Exercise: Implement only read: borrow the supplied committed field and return it in Ok. Keep the alias and struct unchanged.

Hint 1: The receiver is borrowed as &self.
Hint 2: Return Ok(self.committed).

Experiment: Download the source and locate Row, Database, and Session before reading a private helper.
