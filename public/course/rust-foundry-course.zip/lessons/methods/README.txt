Write a method for a struct

Goal: Define a method that reads a struct through &self.
Before this lesson: Give a row a type

A struct groups fields. An impl block groups operations associated with that struct. impl Row { ... } says that the enclosed methods belong to Row.

A method’s &self parameter borrows the instance on which it is called. row.passes() supplies row automatically as self. It follows the shared-borrow rules you already know.

Inside the impl block, Self is another spelling for the implementing type, here Row. Lowercase self is the current instance, while uppercase Self names the type.

Expected output:
true

Exercise: Fix the method’s comparison so exactly fifty passes.

Hint 1: The method needs an inclusive comparison.
Hint 2: Use self.score >= 50.

Experiment: Create a second row with a score below fifty and test the same method.
