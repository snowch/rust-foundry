Rust Foundry — 36 lessons and 8 TinyDB projects

Start with the lesson explanations at https://snowch.github.io/rust-foundry/#course
Each lesson includes a runnable reference and a TODO starter with assertions in main.
Run: rustc --edition 2021 starter.rs -o lesson && ./lesson
TinyDB projects each remove one real function from the complete implementation. The reference includes the native invariant suite. See each project README.

No Cargo dependencies are required. Browser compiler version is experimental and pinned; native tests use stable Rust. Files and source stay local when using the website.
