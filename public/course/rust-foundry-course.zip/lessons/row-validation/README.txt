Define the row contract

Goal: Apply the table’s name rules before accepting a row.
Before this lesson: Read and change rows with SQL; Distinguish bytes from letters; Ask a sequence for its next item

You have seen the people table and its columns. Its name rule allows 1–31 UTF-8 bytes and forbids ASCII control characters. A control character is a byte such as newline or zero that controls text handling rather than displaying a normal letter.

name.is_empty() checks for no bytes. name.bytes().any(predicate) tests whether at least one byte violates the rule. Unlike filter, any passes each byte value directly to its predicate.

Bytes below 32 and the DEL byte 127 are rejected. A positive id, a name meeting this rule, and a u32 score form a valid row; checking id uniqueness additionally needs access to the stored table.

The test helper "é".repeat(16) creates a String containing sixteen copies of that text. It occupies 32 bytes and therefore exceeds the name limit. Validation must happen before changing the database.

Expected output:
name validation passes

Exercise: In the practice editor’s main.rs, replace the todo! line in valid_name. Keep main and its supplied checks. Choose Run checks.

Hint 1: Use name.len() for UTF-8 byte length.
Hint 2: Reject bytes below 32 and the DEL byte 127.

Browser experiment: In the worked program’s main.rs, replace println!("name validation passes"); with println!("{}", valid_name(&"a".repeat(32)));. Run again and compare. Read the boolean. How does the size of this name compare with the byte limit?
