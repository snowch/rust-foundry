fn balanced(text: &str) -> bool {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert!(balanced("([]{})"));
    assert!(balanced("text"));
    assert!(balanced(""));
    assert!(!balanced("([)]"));
    assert!(!balanced("("));
    assert!(!balanced("]"));
    println!("{}", balanced("{[()]}"));
}
