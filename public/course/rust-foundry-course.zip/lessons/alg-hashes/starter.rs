use std::collections::HashMap;

fn counts(text: &str) -> HashMap<&str, usize> {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert!(counts("").is_empty());
    let result = counts("pear apple pear");
    assert_eq!(result.get("pear"), Some(&2));
    assert_eq!(result.get("missing"), None);
    let mut keys: Vec<_> = result.keys().copied().collect();
    keys.sort_unstable();
    for key in keys { println!("{key} {}", result[key]); }
}
