Reject short input safely

A decoder receives bytes, not promises. Check the length before converting a four-byte slice into an array.

Result carries a recoverable error back to the caller. Invalid input must not panic or partially update a database.

Expected output:
258

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Use get(..4) to check the slice bound.
Hint 2: Convert that checked slice into [u8; 4], then decode little-endian.

Experiment: Add a decoder that requires exactly four bytes rather than allowing a suffix.
