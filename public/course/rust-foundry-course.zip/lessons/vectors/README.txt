Keep sorted, unique rows

Vec stores a growable sequence. binary_search returns either the position of an existing key or the insertion position that preserves sorted order.

The index is meaningful only while the vector is sorted. Preserve that invariant after every mutation rather than hoping each caller remembers to sort.

Expected output:
[1, 3, 5]

Exercise: replace todo!; keep the supplied assertions.

Hint 1: Match binary_search instead of doing a second scan.
Hint 2: Use Vec::insert at the missing key’s insertion position.

Experiment: Insert keys smaller than the first and larger than the last.
