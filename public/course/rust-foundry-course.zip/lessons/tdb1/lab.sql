INSERT INTO people VALUES (1, 'Ada', 90);
.export exchange.tdb
SELECT * FROM people;
