struct Node { key: i32, left: Option<Box<Node>>, right: Option<Box<Node>> }

fn insert(root: &mut Option<Box<Node>>, key: i32) {
    todo!("Implement this function using the lesson steps")
}

fn inorder(root: &Option<Box<Node>>, output: &mut Vec<i32>) {
    if let Some(node) = root {
        inorder(&node.left, output); output.push(node.key); inorder(&node.right, output);
    }
}
fn main() {
    let mut root = None;
    for key in [5, 2, 7, 1, 3, 7] { insert(&mut root, key); }
    let mut output = Vec::new(); inorder(&root, &mut output);
    assert_eq!(output, [1, 2, 3, 5, 7]);
    let mut empty = Vec::new(); inorder(&None, &mut empty); assert!(empty.is_empty());
    println!("{:?}", output);
}
