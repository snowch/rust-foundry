trait Identified { fn id(&self) -> u32; }
struct Person { id: u32 }
impl Identified for Person { fn id(&self) -> u32 { self.id } }

fn same_id(left: &Person, right: &Person) -> bool {
    todo!("Implement this function using the lesson steps")
}

fn main() {
    assert!(same_id(&Person { id: 7 }, &Person { id: 7 }));
    assert!(!same_id(&Person { id: 7 }, &Person { id: 8 }));
    println!("{}", same_id(&Person { id: 1 }, &Person { id: 1 }));
}
